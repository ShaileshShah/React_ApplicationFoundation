import React, { useState } from 'react'
import './App.css'
import CDSButton from './components/cdsbutton/cdsbutton'
import CDSHeader from './components/cdsheader/cdsheader'
import TextBox from './components/cdstextbox/cdstextbox'
import Cdslabel from './components/cdslabel/cdslabel'
import { yellow } from '@material-ui/core/colors'
//import CdsSampleStoryBook from './components/cdssamplestoryBook/index'
import CdsSampleTable from './components/cdstable/cdssampletable'
import CDSFooterLayout from './components/cdsFooter/cdsFooterLayout'
import CDSRiskTimelineLayout from './components/cdsRiskTimelineBar/CDSRiskTimelineLayout'
import CDSThresholdBarLayout from './components/cdsd3thresholdbar/cdsd3thresholdbarlayout';


function App() {
  const [textConfig, settextConfig] = useState({
    value: '',
  })

  const [propsData, setpropsData] = useState({
    key: 'appName',
    label: 'Application Name',
    placeholder: 'Application Name',
    inputType: 'text',
    inputDatatype: 'string',
    helperText: 'enter Application name',
    defaultValue: 'defaultValue',
    value: '',
    required: true,
    disabled: false,
  })
  const [validation, setvalidation] = useState({
    required: true,
    requiredErrorMsg: '',
    minLength: 2,
    minLengthErrorMsg: '',
    maxLength: 8,
    maxLengthErrorMsg: '',
    isNumeric: false,
    specialCharacterCheck: true,
    regex: '^[A-Za-z]{0,}[a-zA-Z0-9]{0,}$',
    regexErrorMsg: '',
  })

  const [labelData, setlabelData] = useState({
    label: 'Application Name',
  })

  const [labelVarient, setlabelVarient] = useState({
    State: 'RiskScore',
    RiskScore: 'high',
    OtherState: '',
    Size: 'BannerSize',
  })

  const [customStyle, setcustomStyle] = useState({
    color: 'red',
    background: 'yellow',
    padding: '15px',
    borderRadius: '10px',
  })

  const HandleChange = (event) => {
    settextConfig({ value: event?.target.value })
  }

  const handleClick = () => {}

  return (
    <div className="App">
      <header className="App-header">
        <p>CDS UI App components</p>
        <CDSRiskTimelineLayout />
        <CDSFooterLayout />
        <CDSHeader
          title={'MACE Ideal'}
          subTitle={'Clinical Decision support'}
          headerStyles={'Headline 1 Bold'}
        />
        <br></br>
        <div style={{ background: '#fff', padding: '20px', width: '50%' }}>
          <TextBox
            required={true}
            varientCheck="warning"
            validation={validation}
            fields={propsData}
            customClassLabel={'customClassLabel'}
            customClassInput={'customClassInput'}
            customClassError={'customClassError'}
            textConfig={textConfig}
            disabled={false}
            HandleChangeFunc={HandleChange}
          />
        </div>
        <CDSButton
          customIdName ='cdsButton'
          buttonText={'CDS Button'}
          textColor={'red'}
          btnColor={'white'}
          toolTip={'Button Tooltip'}
          variant={'outlined'}
          disabled={false}
          startIcon={false}
          endIcon={false}
          iconButton={false}
          onClickevent={handleClick}
          width={'30%'}
          justifyContent={'Left'}
        />
        <Cdslabel
          field={labelData}
          varient={labelVarient}
          customStyle={customStyle}
          customClass="customClass"
        />
      </header>
      {/* <CdsSampleStoryBook /> */}
      <div
        style={{
          background: '#fff',
          padding: '20px',
          width: '50%',
          margin: 'auto',
        }}
      >
        <CdsSampleTable />
      </div>
      <div
        style={{
          background: '#fff',
          padding: '20px',
          width: '50%',
          margin: 'auto',
        }}
      >
        <CDSThresholdBarLayout />
      </div>
    </div>
  )
}

export default App
