import React from 'react';
import { render, screen } from '@testing-library/react';
import CDSAplHeader from '../../cdsAppHeader/cdsappheader';



test('renders app header', () => {
    render(<CDSAplHeader title='CDS Heading' subtitle='CDS subheading' desc='CDS APP' />);
    const headerElement = screen.getByText(/CDS Heading/i);
    expect(headerElement).toBeInTheDocument();
});

test('renders app subheader', () => {
    render(<CDSAplHeader title='CDS Heading' subtitle='CDS subheading' desc='CDS APP' />);
    const subheaderElement = screen.getByText(/CDS subheading/i);
    expect(subheaderElement).toBeInTheDocument();
});

test('renders app description', () => {
    render(<CDSAplHeader title='CDS Heading' subtitle='CDS subheading' desc='CDS APP' />);
    const descElement = screen.getByText(/CDS App/i);
    expect(descElement).toBeInTheDocument();
});


