import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import CDSAplHeader from './cdsappheader';

export default {
    title: 'CDS Header with Sub Headers',
    component: CDSAplHeader,

    argTypes: {
        background: { control: 'color' },
        title: 'AMI',
        subtitle: 'CDS',
        desc: 'Description',
        headerStyles: {
            options: ['Headline 1 Bold', 'Headline 1 Regular', 'Headline 2 Bold', 'Headline 2 Regular'],
            control: { type: 'select' },
        },
        subtitleStyles: {
            options: ['Subtitle 1 Bold', 'Subtitle 1 Regular', 'Subtitle 1 Italics', 'Subtitle 2 Bold', 'Subtitle 2 Regular'],
            control: { type: 'select' },
        },
        customStyleHeader: {},
        customStylesubHeader: {},
        customStyleHeaderDesc: {},
        customImageSrc:'Image src'
    },
} as unknown as ComponentMeta<typeof CDSAplHeader>

const Template: ComponentStory<typeof CDSAplHeader> = (args) => (
    <CDSAplHeader {...args} />
)

export const header = Template.bind({})
header.args = {
    title: 'Major Adverse Cardiac Event CDS',
    subtitle: 'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI',
    desc:'(Clinical Decision Support System)',
    headerStyles: 'Headline 1 Bold',
    subtitleStyles: 'Subtitle 1 Bold',
    background: '#e0e0e0',
    customStyleHeader: {},
    customStylesubHeader: {},
    customStyleHeaderDesc: {color:'red'},
    customImageSrc:' '
}