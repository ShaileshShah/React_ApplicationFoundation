import React, { FunctionComponent } from 'react';
import { Typography, Grid } from '@material-ui/core';
import './cdsappheader';
import styled from 'styled-components';
import { useTranslation } from 'react-i18next';
import { HEADER, SUBHEADER } from '../utilities/constants';
import { Box } from '@material-ui/core';

export interface CDSHeaderProps {
    id?:string
    title: string
    subtitle: string
    desc: string
    headerStyles?: string
    subtitleStyles?: string
    background?: string
    customStyleHeader?: {}
    customStylesubHeader?: {}
    customStyleHeaderDesc?: {}
    customImageSrc?: string
    customstyleimage?:{}
}

//Setting generic header styles
const selectHeaderStyles = (val?: string) => {
    switch (val) {
        case 'Headline 1 Bold':
            return {
                family: `${HEADER.font}`,
                size: `${HEADER.header1_fontSize}`,
                lheight: `${HEADER.header1_lineheight}`,
                weight: `${HEADER.bold}`
            }
        case 'Headline 1 Regular':
            return {
                family: `${HEADER.font}`,
                size: `${HEADER.header1_fontSize}`,
                lheight: `${HEADER.header1_lineheight}`,
                weight: `${HEADER.regular}`,
            }
        case 'Headline 2 Bold':
            return {
                family: `${HEADER.font}`,
                size: `${HEADER.header2_fontSize}`,
                lheight: `${HEADER.header2_lineheight}`,
                weight: `${HEADER.bold}`,
            }
        case 'Headline 2 Regular':
            return {
                family: `${HEADER.font}`,
                size: `${HEADER.header2_fontSize}`,
                lheight: `${HEADER.header2_lineheight}`,
                weight: `${HEADER.regular}`,
            }

        default: return {
            family: 'Arial',
            size: '24px',
            lheight: '28px',
            weight: 'normal'
        }
    }
}

//Setting generic sub header styles
const selectSubHeaderStyles = (val?: string) => {
    switch (val) {
        case 'Subtitle 1 Bold':
            return {
                family: `${SUBHEADER.font}`,
                size: `${SUBHEADER.subHeader1_fontSize}`,
                lheight: `${SUBHEADER.subheader1_lineheight}`,
                weight: `${SUBHEADER.bold}`,
            }
        case 'Subtitle 1 Regular':
            return {
                family: `${SUBHEADER.font}`,
                size: `${SUBHEADER.subHeader1_fontSize}`,
                lheight: `${SUBHEADER.subheader1_lineheight}`,
                weight: `${SUBHEADER.regular}`,
            }
        case 'Subtitle 1 Italics':
            return {
                family: `${SUBHEADER.font}`,
                size: `${SUBHEADER.subHeader1_fontSize}`,
                lheight: `${SUBHEADER.subheader1_lineheight}`,
                style: `${SUBHEADER.italics}`,
            }
        case 'Subtitle 2 Bold':
            return {
                family: `${SUBHEADER.font}`,
                size: `${SUBHEADER.subHeader2_fontSize}`,
                lheight: `${SUBHEADER.subheader2_lineheight}`,
                weight: `${SUBHEADER.bold}`,
            }
        case 'Subtitle 2 Regular':
            return {
                family: `${SUBHEADER.font}`,
                size: `${SUBHEADER.subHeader2_fontSize}`,
                lheight: `${SUBHEADER.subheader2_lineheight}`,
                weight: `${SUBHEADER.regular}`,
            }

        default: return {
            family: 'Arial',
            size: '24px',
            lheight: '28px',
            weight: 'bold'
        }
    }
}

const CDSAppHeader = styled(Typography)`
h1{
font-family: ${(props: CDSHeaderProps) =>
        selectHeaderStyles(props.headerStyles).family};

font-weight:${(props: CDSHeaderProps) =>
        selectHeaderStyles(props.headerStyles).weight};

font-size: ${(props: CDSHeaderProps) =>
        selectHeaderStyles(props.headerStyles).size};

line-height: ${(props: CDSHeaderProps) =>
        selectHeaderStyles(props.headerStyles).lheight};
};

span{
    font-size: ${(props: CDSHeaderProps) =>
        props.headerStyles?.startsWith('Headline 1')?'18px':'14px'};
    line-height:${(props: CDSHeaderProps) =>
        props.headerStyles?.startsWith('Headline 2')?'24px':'20px'};
    font-weight:normal;
    };
    
 `

const CDSAppSubHeader = styled(Typography)`
h1{
    font-family: ${(props: CDSHeaderProps) =>
        selectSubHeaderStyles(props.subtitleStyles).family};

    font-weight: ${(props: CDSHeaderProps) =>
        props.subtitleStyles === 'Subtitle 1 Italics' ? 'normal' : selectSubHeaderStyles(props.subtitleStyles).weight};

    font-size: ${(props: CDSHeaderProps) =>
        selectSubHeaderStyles(props.subtitleStyles).size};

    line-height: ${(props: CDSHeaderProps) =>
        selectSubHeaderStyles(props.subtitleStyles).lheight};

    font-style:${(props: CDSHeaderProps) =>
        props.subtitleStyles === 'Subtitle 1 Italics' ? selectSubHeaderStyles(props.subtitleStyles).style : 'normal'};
    margin: unset;    
}
 `

const CustomCard = styled(Box)`
 padding:${HEADER.gridPadding};
 margin-right:1%;
 margin-left:1%;
 `
const ImageCard = styled(Grid)`
 padding:${HEADER.imagePadding};
 display:flex;
 flex-direction:row-reverse !important;
 `
const Image = styled("img")`
    @media (max-width: 576px) {
     width:100px;
     height:100px;
    }
`
const HeaderBox = styled(Grid)`
 width:85%;
 `

const CDSAplHeader: FunctionComponent<CDSHeaderProps> = (props: CDSHeaderProps)  => {
    const { t } = useTranslation(['home', 'main']);


    return (
        <CustomCard 
        style={{ backgroundColor: props.background, display: 'flex', flexDirection: 'row' }}
        >
            <HeaderBox item className='p-8'>
                <CDSAppHeader id={props.id} style={props.customStyleHeader} {...props}><h1>{t(props.title, { ns: ['main', 'home'] })}<span style={props.customStyleHeaderDesc}>{t(props.desc, { ns: ['main', 'home'] })}</span></h1></CDSAppHeader>
                <CDSAppSubHeader style={props.customStylesubHeader} {...props}><h1>{t(props.subtitle, { ns: ['main', 'home'] })}</h1></CDSAppSubHeader>
            </HeaderBox>
            
            <ImageCard item>
                {props.customImageSrc !== '' ? <Image style={props.customstyleimage} src={props.customImageSrc} alt="logo"/> : <Image style={props.customstyleimage} src='src\assets\images\logoblack.png' alt="logo" />}
            </ImageCard>
        </CustomCard>

    )
}
export default CDSAplHeader;