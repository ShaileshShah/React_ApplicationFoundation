import React from 'react';
import CDSAplHeader from './cdsappheader';
import { Box } from '@material-ui/core';

const CDSHeaderLayout = () => {
    return (
        <Box className='d-flex p-2'>
            <ul>
            <li>{'Basic Structure'}</li>
                <CDSAplHeader
                    title={'Application Heading'}
                    subtitle={'Subheading'}
                    desc={'(Heading Desc)'}
                    headerStyles={'Headline 1 Bold'}
                    subtitleStyles={'Subtitle 1 Bold'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
                <li>{'Headline 1 Bold & Subtitle 1 Bold'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 1 Bold'}
                    subtitleStyles={'Subtitle 1 Bold'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
                <li>{'Headline 1 Regular'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 1 Regular'}
                    subtitleStyles={'Subtitle 1 Bold'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
                <li>{'Headline 2 Bold'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 2 Bold'}
                    subtitleStyles={'Subtitle 1 Bold'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
                <li>{'Headline 2 Regular'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 2 Regular'}
                    subtitleStyles={'Subtitle 1 Bold'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />

                <li>{'Sub-Headline 1 Regular'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 2 Regular'}
                    subtitleStyles={'Subtitle 1 Regular'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
                <li>{'Sub-Headline 1 Italics'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 2 Regular'}
                    subtitleStyles={'Subtitle 1 Italics'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
                <li>{'Sub-Headline 2 Bold'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 2 Regular'}
                    subtitleStyles={'Subtitle 2 Bold'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
                <li>{'Sub-Headline 2 Regular'}</li>
                <CDSAplHeader
                    title={'Major Adverse Cardiac Event CDS'}
                    subtitle={'MACE is defined as events that include Acute Mayocardial Infarction,death,CABG or PCI'}
                    desc={'(Clinical Decision Support System)'}
                    headerStyles={'Headline 2 Regular'}
                    subtitleStyles={'Subtitle 2 Regular'}
                    background={'#e0e0e0'}
                    customStyleHeader={{}}
                    customStylesubHeader={{ fontSize: 12 }}
                    customStyleHeaderDesc={{}}
                    customImageSrc={' '}
                />
            </ul>
        </Box>

    )
}
export default CDSHeaderLayout;