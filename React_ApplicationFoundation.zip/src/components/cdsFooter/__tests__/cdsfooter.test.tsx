import React from 'react'
import { render, screen } from '@testing-library/react'
import CDSFooter from '../cdsfooter'
import { columnData,mainDivStylesObj,InnerDivStylesObj } from '../../utilities/data'

describe('CDSFooter', () => {
  const myMock1 = jest.fn();
  test('Renders CDSFooter without Crashing', () => {
    render(
      <CDSFooter
        totalColumns={3}
        columns={columnData}
        background="#e0e0e0"
        bodyStyles="Body Regular"
        mainDivStyles={mainDivStylesObj}
        InnerDivStyles={InnerDivStylesObj}
        downloadFunc={myMock1}
      />
    )
    const orgName = screen.getByText(/Beckman Coulter Diagnostics/i)
    expect(orgName).toBeInTheDocument()
  })

  test('Renders Software Details', () => {
    const myMock1 = jest.fn();
    render(
      <CDSFooter
        totalColumns={3}
        columns={columnData}
        background="#e0e0e0"
        bodyStyles="Body Regular"
        mainDivStyles={mainDivStylesObj}
        InnerDivStyles={InnerDivStylesObj}
        downloadFunc={myMock1}
      />
    )
    const orgName = screen.getByText(/SOFTWARE/i)
    expect(orgName).toBeInTheDocument()
  })

  test('Renders Support Documents Details', () => {
    const myMock1 = jest.fn();
    render(
      <CDSFooter
        totalColumns={3}
        columns={columnData}
        background="#e0e0e0"
        bodyStyles="Body Regular"
        mainDivStyles={mainDivStylesObj}
        InnerDivStyles={InnerDivStylesObj}
        downloadFunc={myMock1}
      />
    )
    const orgName = screen.getByText(/SUPPORT/i)
    expect(orgName).toBeInTheDocument()
  })
})
