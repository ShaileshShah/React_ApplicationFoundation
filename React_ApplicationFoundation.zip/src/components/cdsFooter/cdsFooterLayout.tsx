import React from 'react'
import CDSFooter from './cdsfooter'
import { Box } from '@material-ui/core'
import { columnData,mainDivStylesObj,InnerDivStylesObj } from '../utilities/data'

const downloadFunction =()=>{}
const CDSFooterLayout = () => {
  return (
    <Box className="d-flex p-2">
      <ul>
        <li>Basic Structure Regular</li>
        <CDSFooter
          id="cdsHeader"
          totalColumns={3}
          columns={columnData}
          background="#e0e0e0"
          bodyStyles="Body Regular"
          mainDivStyles={mainDivStylesObj}
          InnerDivStyles={InnerDivStylesObj}
          downloadFunc={downloadFunction}
        />
      </ul>
    </Box>
  )
}
export default CDSFooterLayout
