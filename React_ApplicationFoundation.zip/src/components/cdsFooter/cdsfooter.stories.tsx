import React from 'react'
import { ComponentStory, ComponentMeta } from '@storybook/react'
import CDSFooter from './cdsfooter'

export default {
  title: 'CDS Footer',
  id:'cdsFooter',
  component: CDSFooter,
  argTypes: {
    totalColumns: 1,
    columns: [{ lines: [], style: {} }],
    background: { control: 'color' },
    captionStyles: {
      options: ['Caption Regular', 'Caption Bold'],
      control: { type: 'select' },
    },
    subtitleStyles: {
      options: ['Subtitle Bold', 'Subtitle Regular'],
      control: { type: 'select' },
    },
    bodyStyles: {
      options: ['Body Bold', 'Body Regular'],
      control: { type: 'select' },
    },
  },
} as unknown as ComponentMeta<typeof CDSFooter>

const Template: ComponentStory<typeof CDSFooter> = (args) => (
  <CDSFooter {...args} />
)

export const footer = Template.bind({})

footer.args = {}
