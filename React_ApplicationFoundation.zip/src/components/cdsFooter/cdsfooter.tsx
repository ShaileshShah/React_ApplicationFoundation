import React, { FunctionComponent } from 'react'
import { Box, Grid, Typography } from '@material-ui/core'
import styled from 'styled-components'
import { FOOTERSUBTITLE } from '../utilities/constants'
import { GetIcons } from '../utilities/GetIcons'

interface LineStyles {
  label?: string
  hyperLink?: boolean
  link?: string
  targetBlank?: string
  icon?: string
  startIcon?: boolean
  endIcon?: boolean
  iconStyle?: {},
  className?: string
  idName?: string
  download?:boolean
  style?: {
    fontSize?: string
    textStyle?: string
    fontWeight?: string
    color?: string
    lineHeight?: string
  }
}
export interface ColumnsGrid {
  lines: LineStyles[]
  style?: {}
}
export interface CDSFooterProps {
  id?:string
  totalColumns: number
  columns: ColumnsGrid[]
  background?: string
  bodyStyles: string
  mainDivStyles:{}
  InnerDivStyles:{} 
  downloadFunc:any
}


const CDSFooter: FunctionComponent<CDSFooterProps> = (
  props: CDSFooterProps
) => {
  //Footer Wrapper
  const FooterWrapper = styled(Box)`
    padding: ${FOOTERSUBTITLE.gridPadding};
    border-top: 1px solid #979797;
  `

  const ColumnGrid = styled(Grid)`
    align-items: baseline;
  `

  const ColumnGridItem = styled(Grid)``


  //Text Label Styles
  const TextLabelStyles = (val?: string) => {
    switch (val) {
      default:
        return {
          family: 'Arial',
          size: '12px',
          lheight: '10px',
          weight: 'normal',
          color: 'black',
        }
    }
  }
  const TextLabel = styled(Typography)`
    h1 {
      font-family: ${TextLabelStyles(props.bodyStyles).family};
      font-weight: ${TextLabelStyles(props.bodyStyles).weight};
      font-size: ${TextLabelStyles(props.bodyStyles).size};
      line-height: ${TextLabelStyles(props.bodyStyles).lheight};
      font-style: ${TextLabelStyles(props.bodyStyles)};
      color: ${TextLabelStyles(props.bodyStyles).color};
      display: flex;
      align-items: center;
    }

    svg {
      height: inherit;
      width: 15px;
    }
  `

  return (
    <FooterWrapper id={props?.id} style={{ backgroundColor: props.background,...props.mainDivStyles }}>
      {props?.totalColumns === props?.columns?.length ? (
        <ColumnGrid container spacing={4} style={props.InnerDivStyles} >
          {props.columns?.map((col) => (
            <ColumnGridItem item style={col.style}>
              {col?.lines?.map((line) => {
                if (line.hyperLink) {
                  return <a href={line.link} onClick={props.downloadFunc} target={line.targetBlank} key={Date.now()} download={line.download} style={line.style}>
                    <TextLabel className={line.className} id={line.idName} style={line.style}>
                      {line.startIcon ? <span style={line.iconStyle}>{GetIcons(line.icon, line.iconStyle)}</span> : ""}
                      {line.label}
                      {line.endIcon ? <span style={line.iconStyle}>{GetIcons(line.icon, line.iconStyle)}</span> : ""}
                    </TextLabel>             
                  </a>
                } else {
                  return <TextLabel className={line.className} id={line.idName}>
                    <h1 key={Date.now()} style={line.style}>
                      {line.startIcon ? <span style={line.iconStyle}>{GetIcons(line.icon, line.iconStyle)}</span> : ""}
                      {line.label}
                      {line.endIcon ? <span style={line.iconStyle}>{GetIcons(line.icon, line.iconStyle)}</span> : ""}
                    </h1>
                  </TextLabel>
                }
              })}
            </ColumnGridItem>
          ))}
        </ColumnGrid>
      ) : (
        <h1>Columns Mismatch</h1>
      )}
    </FooterWrapper>
  )
}

export default CDSFooter
