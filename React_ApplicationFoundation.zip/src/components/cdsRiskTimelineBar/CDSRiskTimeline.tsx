import React, { FunctionComponent, useEffect, useRef } from 'react'
import * as d3 from 'd3'
import { RISKTIMELINE as CONST } from '../utilities/constants'
import { timelineUtils as utils } from './RiskTimelineUtils'

interface RiskScore {
  riskscore: number
  time: string
}

export interface CDSRiskTimelineProps {
  id?:string
  lowColor?: string
  lowPointerColor?: string
  lowRangeMin?: number
  lowRangeMax?: number
  lowLabel?: string | any

  intermediatecolor?: string
  intermediatePointerColor?: string
  intermRangeMin?: number
  intermRangeMax?: number
  intLabel?: string | any

  highColor?: string
  highPointerColor?: string
  highRangeMin?: number
  highRangeMax?: number
  highLabel?: string | any

  rangeMax?: number
  rangeMin?: number
  riskScores?: Array<RiskScore>
  onClickEvent: (riskScore: any) => void
}

const CDSRiskTimeline: FunctionComponent<CDSRiskTimelineProps> = (
  props: CDSRiskTimelineProps
) => {
  const riskTImelineRef = useRef<SVGSVGElement | null>(null)

  const ranges = {
      lowMin: props.lowRangeMin ? props.lowRangeMin : CONST.lowMin,
      lowMax: props.lowRangeMax ? props.lowRangeMax : CONST.lowMax,
      intMin: props.intermRangeMin ? props.intermRangeMin : CONST.intMin,
      intMax: props.intermRangeMax ? props.intermRangeMax : CONST.intMax,
      highMin: props.highRangeMin ? props.highRangeMin : CONST.highMin,
      highMax: props.highRangeMax ? props.highRangeMax : CONST.highMax,
    },
    riskScoreArr = props.riskScores,
    dataSetLength = utils.dataSet(props.rangeMax, props.rangeMin).length,
    labelData = [
      {
        scale: (ranges.highMax + ranges.intMax) / 2,
        label: props.highLabel ? props.highLabel : CONST.highLabel,
      },
      { scale: (ranges.intMax + ranges.lowMax) / 2, label: props.intLabel },
      {
        scale: ranges.lowMax / 2,
        label: props.lowLabel ? props.lowLabel : CONST.lowLabel,
      },
      { scale: -0.25, label: 'Time' },
    ]

  useEffect(() => {
    const svg = d3.select(riskTImelineRef.current),
      margin = {
        top: CONST.topMargin,
        right: CONST.rightMargin,
        bottom: CONST.bottomMargin,
        left: CONST.leftMargin,
      },
      svgHeight = +svg.attr('height') - margin.top - margin.bottom,
      svgWidth = +svg.attr('width') - margin.left

    let lastScore = 0

    const g = svg
        .append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`),
      yScale = d3.scaleLinear().domain([0, dataSetLength]).range([svgHeight, 0])

    g.selectAll('.bar')
      .data(utils.dataSet(props?.rangeMax, props.rangeMin))
      .enter()
      .append('rect')
      .attr('y', (_d: any, i: any) => {
        return i * (svgHeight / dataSetLength)
      })
      .attr('x', 0)
      .attr('width', svgWidth)
      .attr('height', svgHeight / dataSetLength)
      .attr('transform', (d: number) => utils.tierGap(d, ranges))
      .style('fill', (d: number) => utils.tierColor(d, ranges, props))

    svg
      .selectAll('.label')
      .data(labelData)
      .enter()
      .append('text')
      .attr('x', 55)
      .attr('y', (labelData) => yScale(labelData.scale) + 54)
      .attr('text-anchor', 'end')
      .text((labelData) => labelData.label)
      .attr('font-size', '8px')
      .attr('font-family', 'Arial')
      .attr('font-weight', 550)
      .attr('fill', (labelData) => utils.textColor(labelData.label, props))

    //border left style for bar
    utils?.dataSet(props.rangeMax, props.rangeMin)?.map((data) => {
      return g
        .append('line')
        .attr('x1', 0)
        .attr('x2', 0)
        .attr('y1', () =>
          data <= ranges.lowMax
            ? yScale(-(ranges.lowMax / 2) * 0.15)
            : data >= ranges.intMin && data <= ranges.intMax
            ? yScale(ranges.lowMax - dataSetLength / 100)
            : data >= ranges.highMin
            ? yScale(ranges.intMax)
            : yScale(ranges.intMax)
        )

        .attr('y2', () =>
          data <= ranges.lowMax
            ? yScale(ranges.lowMax - (ranges.lowMax / 2) * 0.15)
            : data >= ranges.intMin && data <= ranges.intMax
            ? yScale(ranges.intMax - dataSetLength / 100)
            : data >= ranges.highMin
            ? yScale(ranges.highMax)
            : yScale(ranges.highMax)
        )

        .attr('stroke', utils.pointerColor(data, ranges, props))
        .attr('stroke-width', '1px')
    })

    riskScoreArr?.forEach((riskScore, i) => {
      // vertical Line
      const verticalLine = g
        .append('line')
        .attr('x1', () => utils.xCoordinate(i, svgWidth, riskScoreArr))
        .attr('x2', () => utils.xCoordinate(i, svgWidth, riskScoreArr))
        .attr('y1', yScale(-(ranges.lowMax / 2) * 0.1))
        .attr('y2', () =>
          riskScore.riskscore <= ranges.lowMax
            ? yScale(riskScore.riskscore - (riskScore.riskscore / 2) * 0.1)
            : riskScore.riskscore >= ranges.intMin &&
              riskScore.riskscore <= ranges.intMax
            ? yScale(riskScore.riskscore - riskScoreArr.length / 100)
            : riskScore.riskscore >= ranges.highMin
            ? yScale(riskScore.riskscore)
            : yScale(riskScore.riskscore)
        )
        .classed('selected', i === riskScoreArr.length - 1 ? true : false)
        .attr('stroke', () => {
          return i === riskScoreArr.length - 1
            ? utils.pointerColor(riskScore.riskscore, ranges, props)
            : utils.toolTipColor(riskScore.riskscore, ranges)
        })
        .attr('stroke-width', CONST.toolTipStroke)
        .style('cursor', 'pointer')

      verticalLine
        .on('mouseover', () => {
          addHoverEvents(rectBar, riskScore.riskscore, 'rect')
          addHoverEvents(verticalLine, riskScore.riskscore, 'line')
          addHoverEvents(circleDisc, riskScore.riskscore, 'circle')
        })
        .on('mouseout', () => {
          removeHoverEvents(rectBar, riskScore.riskscore, 'rect')
          removeHoverEvents(verticalLine, riskScore.riskscore, 'line')
          removeHoverEvents(circleDisc, riskScore.riskscore, 'circle')
        })

      const rectBar = g
        .append('rect')
        .attr(
          'x',
          () =>
            utils.xCoordinate(i, svgWidth, riskScoreArr) -
            utils.toolTipWidth(riskScore.riskscore, ranges) / 2
        )
        .attr('y', () =>
          riskScore.riskscore <= ranges.lowMax
            ? yScale(riskScore.riskscore - (riskScore.riskscore / 2) * 0.1)
            : riskScore.riskscore >= ranges.intMin &&
              riskScore.riskscore <= ranges.intMax
            ? yScale(riskScore.riskscore - riskScoreArr?.length / 100)
            : riskScore.riskscore >= ranges.highMin
            ? yScale(riskScore.riskscore)
            : yScale(riskScore.riskscore)
        )
        .attr('width', () => utils.toolTipWidth(riskScore.riskscore, ranges))
        .attr('height', () => svgHeight / dataSetLength)
        .attr('rx', CONST.rectRadius)
        .attr('ry', CONST.rectRadius)
        .classed('selected', i === riskScoreArr.length - 1 ? true : false)
        .style('fill', () => {
          return i === riskScoreArr.length - 1
            ? utils.addToolTipColor(
                'active',
                utils.tierCategory(riskScore.riskscore, ranges)
              ).rectColor //latest risk-score(darken-shade)
            : utils.toolTipColor(riskScore.riskscore, ranges) //past risk-score(faded shade)
        })
        .style('stroke', () => {
          return i === riskScoreArr.length - 1
            ? utils.addToolTipColor(
                'active',
                utils.tierCategory(riskScore.riskscore, ranges)
              ).circleLineStroke //latest risk-score(darken-shade)
            : utils.toolTipColor(riskScore.riskscore, ranges) //past risk-score(faded shade)
        })
        .style('stroke-width', '2px')
        .style('cursor', 'pointer')
      lastScore = riskScore.riskscore

      rectBar
        .on('click', () => {
          inactiveToolTip(g, lastScore)
          addClickEvent(rectBar, riskScore.riskscore, 'rect')
          addClickEvent(verticalLine, riskScore.riskscore, 'line')
          addClickEvent(circleDisc, riskScore.riskscore, 'circle')
          lastScore = riskScore.riskscore
          props.onClickEvent(riskScore)
        })
        .on('mouseover', () => {
          addHoverEvents(rectBar, riskScore.riskscore, 'rect')
          addHoverEvents(verticalLine, riskScore.riskscore, 'line')
          addHoverEvents(circleDisc, riskScore.riskscore, 'circle')
        })
        .on('mouseout', () => {
          removeHoverEvents(rectBar, riskScore.riskscore, 'rect')
          removeHoverEvents(verticalLine, riskScore.riskscore, 'line')
          removeHoverEvents(circleDisc, riskScore.riskscore, 'circle')
        })

      //text inside box
      g.append('text')
        .attr(
          'x',
          () =>
            utils.xCoordinate(i, svgWidth, riskScoreArr) -
            utils.toolTipWidth(riskScore.riskscore, ranges) / 2.75
        )
        .attr('y', () =>
          riskScore.riskscore <= ranges.lowMax
            ? yScale(
                (riskScore.riskscore + (riskScore.riskscore - 1)) / 2 - 0.3
              )
            : riskScore.riskscore >= ranges.intMin &&
              riskScore.riskscore <= ranges.intMax
            ? yScale(
                (riskScore.riskscore + (riskScore.riskscore - 1)) / 2 - 0.3
              )
            : riskScore.riskscore >= ranges.highMin
            ? yScale(
                (riskScore.riskscore + (riskScore.riskscore - 1)) / 2 - 0.2
              )
            : ''
        )

        .text(() =>
          riskScore.riskscore >= ranges.highMin
            ? `${props.highLabel}, ${riskScore.riskscore}`
            : riskScore.riskscore <= ranges.lowMax
            ? `${props.lowLabel}, ${riskScore.riskscore}`
            : riskScore.riskscore >= ranges.intMin &&
              riskScore.riskscore <= ranges.intMax
            ? `${props.intLabel}, ${riskScore.riskscore}`
            : ''
        )
        .style('fill', () =>
          riskScore.riskscore >= ranges.highMin ? 'white' : 'black'
        )
        .style('font-size', '9px')
        .style('font-weight', 'bold')
        .style('pointer-events', 'none')

      //pointer at bottom
      const circleDisc = g
        .append('circle')
        .attr('cx', () => utils.xCoordinate(i, svgWidth, riskScoreArr))
        .attr('cy', yScale(-0.25))
        .attr('r', CONST.pointRadius)
        .classed('selected', i === riskScoreArr.length - 1 ? true : false)
        .style('fill', () =>
          i === riskScoreArr.length - 1
            ? utils.pointerColor(riskScore.riskscore, ranges, props)
            : utils.toolTipColor(riskScore.riskscore, ranges)
        )
        .style('cursor', 'pointer')

      circleDisc
        .on('mouseover', () => {
          addHoverEvents(rectBar, riskScore.riskscore, 'rect')
          addHoverEvents(verticalLine, riskScore.riskscore, 'line')
          addHoverEvents(circleDisc, riskScore.riskscore, 'circle')
        })
        .on('mouseout', () => {
          removeHoverEvents(rectBar, riskScore.riskscore, 'rect')
          removeHoverEvents(verticalLine, riskScore.riskscore, 'line')
          removeHoverEvents(circleDisc, riskScore.riskscore, 'circle')
        })

      g.append('text')
        .attr('x', () => utils.xCoordinate(i, svgWidth, riskScoreArr))
        .attr('y', yScale(0) + 20)
        .text(riskScore.time)
        .style('fill', 'black')
        .style('font-size', CONST.xAxisTickSize)
        .style('text-anchor', 'middle')
    })
  }, [])

  const addClickEvent = (_elem: any, _riskScore: number, _elemName: string) => {
    _elem
      .classed('selected', true)
      .style('fill', () =>
        _elemName === 'circle'
          ? utils.addToolTipColor(
              'active',
              utils.tierCategory(_riskScore, ranges)
            ).circleLineStroke
          : utils.addToolTipColor(
              'active',
              utils.tierCategory(_riskScore, ranges)
            ).rectColor
      )
      .style(
        'stroke',
        utils.addToolTipColor('active', utils.tierCategory(_riskScore, ranges))
          .circleLineStroke
      )
      .style('stroke-width', '2px')
  }
  const addHoverEvents = (
    _elem: any,
    _riskScore: number,
    _elemName: string
  ) => {
    _elem
      .transition()
      .style('fill', () => {
        return _elemName === 'circle'
          ? utils.addToolTipColor(
              'active',
              utils.tierCategory(_riskScore, ranges)
            ).circleLineStroke
          : utils.addToolTipColor(
              'active',
              utils.tierCategory(_riskScore, ranges)
            ).rectColor
      })
      .style(
        'stroke',
        utils.addToolTipColor('active', utils.tierCategory(_riskScore, ranges))
          .circleLineStroke
      )
      .style('stroke-width', '2px')
  }
  const removeHoverEvents = (
    _elem: any,
    _riskScore: number,
    _elemName: string
  ) => {
    _elem.classed('selected')
      ? _elem
          .transition()
          .style('fill', () =>
            _elemName === 'circle'
              ? utils.addToolTipColor(
                  'active',
                  utils.tierCategory(_riskScore, ranges)
                ).circleLineStroke
              : utils.addToolTipColor(
                  'active',
                  utils.tierCategory(_riskScore, ranges)
                ).rectColor
          )
          .style(
            'stroke',
            utils.addToolTipColor(
              'active',
              utils.tierCategory(_riskScore, ranges)
            ).circleLineStroke
          )
          .style('stroke-width', '2px')
      : _elem
          .transition()
          .style('fill', utils.toolTipColor(_riskScore, ranges))
          .style('stroke', utils.toolTipColor(_riskScore, ranges))
          .style('stroke-width', '1.5px')
  }
  const inactiveToolTip = (_g: any, _score: number) => {
    _g.selectAll('.selected')
      .style('fill', utils.toolTipColor(_score, ranges))
      .style('stroke', utils.toolTipColor(_score, ranges))
      .attr('class', null)
  }

  return (
    <svg
      id = "cdsRiskChart"
      ref={riskTImelineRef}
      width={450}
      height={utils.calculateHeight(ranges)}
    ></svg>
  )
}

export default CDSRiskTimeline
