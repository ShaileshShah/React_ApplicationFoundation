import React from 'react'
import CDSRiskTimeline from './CDSRiskTimeline'

const CDSRiskTimelineLayout = () => {
  const riskScores = [
    { riskscore: 2, time: '1130' },
    { riskscore: 4, time: '1210' },
    { riskscore: 8, time: '1810' },
    { riskscore: 3, time: '1810' },

  ]

  function toolTipClick(_riskcore:any) {
    console.log(_riskcore)
    console.log('Called From Parent')
  }

  return (
    <>
      <CDSRiskTimeline
        id='cdsRiskChart'
        lowColor="#E8F0F8"
        intermediatecolor="#F4F4F4"
        highColor="#F7E9E8"
        lowRangeMin={1}
        lowRangeMax={3}
        intermRangeMin={4}
        intermRangeMax={5}
        highRangeMin={6}
        highRangeMax={10}
        rangeMin={1}
        rangeMax={10}
        lowPointerColor={'#1C68B8'}
        intermediatePointerColor={'#CACACA'}
        highPointerColor={'#AC2419'}
        riskScores={riskScores}
        onClickEvent={toolTipClick}
        lowLabel={'Low'}
        intLabel={'Indeterminate'}
        highLabel={'High'}
      />
    </>
  )
}
export default CDSRiskTimelineLayout
