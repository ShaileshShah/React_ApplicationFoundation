import { RISKTIMELINE as CONST, COLOR } from '../utilities/constants'
import { CDSRiskTimelineProps } from './CDSRiskTimeline'

export const timelineUtils = {
  calculateHeight: (_range: any) => _range.highMax * 25.5,

  dataSet: (max: number | any, min: number | any) => {
    let dataArray = []
    for (var i = max; i >= min; i--) {
      dataArray.push(i)
    }
    return dataArray
  },

  tierColor: (
    _val: number,
    _range: any,
    _props: CDSRiskTimelineProps
  ): string | any =>
    _val <= _range.lowMax
      ? _props.lowColor
        ? _props.lowColor
        : CONST.lowPointerColor
      : _val >= _range.intMin && _val <= _range.intMax
      ? _props.intermediatecolor
        ? _props.intermediatecolor
        : CONST.intPointerColor
      : _val >= _range.highMin
      ? _props.highColor
        ? _props.highColor
        : CONST.highPointerColor
      : _props.highColor,

  pointerColor: (
    _val: number,
    _range: any,
    _props: CDSRiskTimelineProps
  ): string | any =>
    _val <= _range.lowMax
      ? _props.lowPointerColor
        ? _props.lowPointerColor
        : CONST.lowPointerColor
      : _val >= _range.intMin && _val <= _range.intMax
      ? _props.intermediatePointerColor
        ? _props.intermediatePointerColor
        : CONST.intPointerColor
      : _val >= _range.highMin
      ? _props.highPointerColor
        ? _props.highPointerColor
        : CONST.highPointerColor
      : _props.highPointerColor,

  toolTipColor: (_val: number, _range: any): string | any =>
    _val <= _range.lowMax
      ? CONST.lowTierColor
      : _val >= _range.intMin && _val <= _range.intMax
      ? CONST.intTierColor
      : _val >= _range.highMin
      ? CONST.highTierColor
      : CONST.highTierColor,

  textColor: (_label: string, _props: CDSRiskTimelineProps): string | any =>
    _label.toLowerCase() === _props.lowLabel.toLowerCase()
      ? _props.lowPointerColor
      : _label.toLowerCase() === _props.intLabel.toLowerCase()
      ? _props.intermediatePointerColor
      : _label.toLowerCase() === _props.highLabel.toLowerCase()
      ? _props.highPointerColor
      : null,

  xCoordinate: (_index: number, _width: number, _arr: any): number => {
    let eleNum = _arr?.length,
      eleMultiplier = eleNum + 1,
      xCoordinate = _width / eleMultiplier

    return (_index + 1) * xCoordinate
  },

  toolTipWidth: (_value: number, _range: any): number =>
    _value >= _range.intMin && _value <= _range.intMax
      ? CONST.toolTtipWidth
      : CONST.toolTipWidthLow,

  tierGap: (_value: number, _range: any): string =>
    _value <= _range.lowMax
      ? `translate(0,4)`
      : _value >= _range.intMin && _value <= _range.intMax
      ? `translate(0,2)`
      : 'translate(0,0)',

  addToolTipColor: (state: string, range: string) => {
    if (state === 'idle') {
      return range === 'low'
        ? COLOR.idle.low
        : range === 'int'
        ? COLOR.idle.int
        : COLOR.idle.high
    } else {
      return range === 'low'
        ? COLOR.active.low
        : range === 'int'
        ? COLOR.active.int
        : COLOR.active.high
    }
  },

  tierCategory: (_val: number, _range: any): string => {
    return _val <= _range.lowMax
      ? 'low'
      : _val >= _range.intMin && _val <= _range.intMax
      ? 'int'
      : _val >= _range.highMin
      ? 'high'
      : 'high'
  },
}
