import 'react-app-polyfill/ie11'
import 'react-app-polyfill/stable'
import React from 'react'
import { render } from '@testing-library/react'
import CDSRiskTimeline from '../CDSRiskTimeline'

const riskScores = [
  { riskscore: 2, time: '1130' },
  { riskscore: 4, time: '1210' },
  { riskscore: 8, time: '1810' },
  { riskscore: 3, time: '1810' },
]

function toolTipClick(_riskcore: any) {
  console.log(_riskcore)
  console.log('Called From Parent')
}

test('Render Risk Timeline Bar', () => {
  const { container } = render(
    <CDSRiskTimeline
      lowColor="#E8F0F8"
      intermediatecolor="#F4F4F4"
      highColor="#F7E9E8"
      lowRangeMin={1}
      lowRangeMax={3}
      intermRangeMin={4}
      intermRangeMax={5}
      highRangeMin={6}
      highRangeMax={10}
      rangeMin={1}
      rangeMax={10}
      lowPointerColor={'#1C68B8'}
      intermediatePointerColor={'#CACACA'}
      highPointerColor={'#AC2419'}
      riskScores={riskScores}
      onClickEvent={toolTipClick}
      lowLabel={'Low'}
      intLabel={'Indeterminate'}
      highLabel={'High'}
    />
  )

  const path = container.querySelector('rect')
  expect(path?.getAttribute('x')).not.toMatch(/NaN|undefined/)
  expect(path?.getAttribute('d')).not.toBe('')
})

test('render scalebar with x parameter', () => {
  const { container } = render(
    <CDSRiskTimeline
      lowColor="#E8F0F8"
      intermediatecolor="#F4F4F4"
      highColor="#F7E9E8"
      lowRangeMin={1}
      lowRangeMax={3}
      intermRangeMin={4}
      intermRangeMax={5}
      highRangeMin={6}
      highRangeMax={10}
      rangeMin={1}
      rangeMax={10}
      lowPointerColor={'#1C68B8'}
      intermediatePointerColor={'#CACACA'}
      highPointerColor={'#AC2419'}
      riskScores={riskScores}
      onClickEvent={toolTipClick}
      lowLabel={'Low'}
      intLabel={'Indeterminate'}
      highLabel={'High'}
    />
  )

  const path = container.querySelector('rect')
  expect(path?.getAttribute('x')).toBe('0')
})

test('render scalebar with y parameter', () => {
  const { container } = render(
    <CDSRiskTimeline
      lowColor="#E8F0F8"
      intermediatecolor="#F4F4F4"
      highColor="#F7E9E8"
      lowRangeMin={1}
      lowRangeMax={3}
      intermRangeMin={4}
      intermRangeMax={5}
      highRangeMin={6}
      highRangeMax={10}
      rangeMin={1}
      rangeMax={10}
      lowPointerColor={'#1C68B8'}
      intermediatePointerColor={'#CACACA'}
      highPointerColor={'#AC2419'}
      riskScores={riskScores}
      onClickEvent={toolTipClick}
      lowLabel={'Low'}
      intLabel={'Indeterminate'}
      highLabel={'High'}
    />
  )

  const path = container.querySelector('rect')
  expect(path?.getAttribute('y')).toBe('0')
})

test('render scalebar with styles for box', () => {
  const { container } = render(
    <CDSRiskTimeline
      lowColor="#E8F0F8"
      intermediatecolor="#F4F4F4"
      highColor="#F7E9E8"
      lowRangeMin={1}
      lowRangeMax={3}
      intermRangeMin={4}
      intermRangeMax={5}
      highRangeMin={6}
      highRangeMax={10}
      rangeMin={1}
      rangeMax={10}
      lowPointerColor={'#1C68B8'}
      intermediatePointerColor={'#CACACA'}
      highPointerColor={'#AC2419'}
      riskScores={riskScores}
      onClickEvent={toolTipClick}
      lowLabel={'Low'}
      intLabel={'Indeterminate'}
      highLabel={'High'}
    />
  )

  const path = container.querySelector('rect')
  expect(path).toHaveStyle('fill:#F7E9E8')
})

test('render scalebar with styles for text svg', () => {
  const { container } = render(
    <CDSRiskTimeline
      lowColor="#E8F0F8"
      intermediatecolor="#F4F4F4"
      highColor="#F7E9E8"
      lowRangeMin={1}
      lowRangeMax={3}
      intermRangeMin={4}
      intermRangeMax={5}
      highRangeMin={6}
      highRangeMax={10}
      rangeMin={1}
      rangeMax={10}
      lowPointerColor={'#1C68B8'}
      intermediatePointerColor={'#CACACA'}
      highPointerColor={'#AC2419'}
      riskScores={riskScores}
      onClickEvent={toolTipClick}
      lowLabel={'Low'}
      intLabel={'Indeterminate'}
      highLabel={'High'}
    />
  )

  const path = container.querySelector('text')
  console.log(path?.style)
})
