import React, { FunctionComponent } from 'react'
import { Box, Grid, Typography } from '@material-ui/core'
import styled from 'styled-components'
import { GetIcons } from '../utilities/GetIcons'

interface TextBlockLines {
  label?: string
  hyperLink?: boolean
  link?: string
  targetBlank?: string
  icon?: string
  startIcon?: boolean
  endIcon?: boolean
  iconStyle?: {}
  download?: boolean
  style?: {}
}

interface TextBlockData {
  subHeading?: string
  bulletList?: boolean
  numberedList?: boolean
  lines: Array<TextBlockLines>
}

export interface CDSTextBlockProps {
  header?: string
  totalColumns: number
  backgroundColor: string
  columns: Array<TextBlockData>
}

const TextBlockWrapper = styled(Box)`
  margin: 1%;
  padding: 10px;
  border-top: 1px solid #979797;
`

const TextBlockHeader = styled(Typography)`
  h1 {
    font-family: Arial;
    font-weight: 700;
    font-size: 0.8rem;
    line-height: 16px;
    color: #181818;
  }
`

const TextBlockSubHeader = styled(Typography)`
  h1 {
    font-family: Arial;
    font-weight: 700;
    font-size: 0.8rem;
    line-height: 16px;
    color: #181818;
  }
`

const TextBlockLine = styled(Typography)`
  h1 {
    font-family: Arial;
    font-weight: 400;
    font-size: 0.7rem;
    line-height: 12px;
    font-style: normal;
    color: #181818;
  }

  svg {
    height: inherit;
    width: 15px;
  }
`

const ColumnGrid = styled(Grid)`
  align-items: flex-start;
  flex-wrap: nowrap !important;
`

const ColumnGridItem = styled(Grid)`
  width: inherit;
  padding: 0 5px 0 5px;
  ul,
  ol {
    margin: 0 0 0 20px;
    padding: 0;
  }
  li {
    font-size: 0.8rem;
  }
`

const CDSTextBlock: FunctionComponent<CDSTextBlockProps> = (
  props: CDSTextBlockProps
) => {
  return (
    <TextBlockWrapper id="cdsTextBlock" style={{ backgroundColor: props.backgroundColor }}>
      {props.header ? (
        <TextBlockHeader>
          <h1>{props.header}</h1>
        </TextBlockHeader>
      ) : null}
      {props.totalColumns === props.columns?.length ? (
        <ColumnGrid container spacing={2}>
          {props.columns.map((col, _ind) => (
            <ColumnGridItem item key={Date.now() + _ind}>
              <>
                {col?.subHeading ? (
                  <TextBlockSubHeader>
                    <h1>{col?.subHeading}</h1>
                  </TextBlockSubHeader>
                ) : null}

                {col.bulletList ? (
                  <ul>
                    {col?.lines.map((line) => (
                      <li>
                        <TextBlockLine
                          key={Date.now() + Math.random()}
                          style={line.style}
                        >
                          <h1>{line.label}</h1>
                        </TextBlockLine>
                      </li>
                    ))}
                  </ul>
                ) : col.numberedList ? (
                  <ol>
                    {col?.lines.map((line) => (
                      <li>
                        <TextBlockLine
                          key={Date.now() + Math.random()}
                          style={line.style}
                        >
                          <h1>{line.label}</h1>
                        </TextBlockLine>
                      </li>
                    ))}
                  </ol>
                ) : (
                  <>
                    {col?.lines.map((line) => (
                      <>
                        {line.hyperLink ? (
                          <a
                            href={line.link}
                            target={line.targetBlank}
                            key={Date.now()}
                            download={line.download}
                          >
                            <TextBlockLine
                              key={Date.now() + Math.random()}
                              style={line.style}
                            >
                              {line.startIcon ? (
                                <span style={line.iconStyle}>
                                  {GetIcons(line.icon, line.iconStyle)}
                                </span>
                              ) : null}
                              <h1>{line.label}</h1>
                              {line.endIcon ? (
                                <span style={line.iconStyle}>
                                  {GetIcons(line.icon, line.iconStyle)}
                                </span>
                              ) : null}
                            </TextBlockLine>
                          </a>
                        ) : (
                          <TextBlockLine key={Date.now() + Math.random()}>
                            {line.startIcon ? (
                              <span style={line.iconStyle}>
                                {GetIcons(line.icon, line.iconStyle)}
                              </span>
                            ) : null}
                            <h1 style={line.style}>{line.label}</h1>
                            {line.endIcon ? (
                              <span style={line.iconStyle}>
                                {GetIcons(line.icon, line.iconStyle)}
                              </span>
                            ) : null}
                          </TextBlockLine>
                        )}
                      </>
                    ))}
                  </>
                )}
              </>
            </ColumnGridItem>
          ))}
        </ColumnGrid>
      ) : (
        <>Columns Mismatch</>
      )}
    </TextBlockWrapper>
  )
}

export default CDSTextBlock
