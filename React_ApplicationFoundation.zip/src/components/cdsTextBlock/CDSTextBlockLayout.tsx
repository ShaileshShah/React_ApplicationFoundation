import React from 'react'
import CDSTextBlock from './CDSTextBlock'
import { textBlockData as data } from '../utilities/data'

const CDSTextBlockLayout = () => {
  return (
      <CDSTextBlock
        header={data.header}
        totalColumns={data.totalCol}
        backgroundColor={data.bgColor}
        columns={data.columns}
      />
  )
}
export default CDSTextBlockLayout
