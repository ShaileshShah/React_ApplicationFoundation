import React from 'react'
import { render, screen } from '@testing-library/react'
import CDSTextBlock from '../CDSTextBlock'

const textBlockData = [
    {
      subHeading: 'SUB Header',
      lines: [
        {
          label:
            'Lorem ipsum dolorLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Facilisis gravida neque convallis a cras semper auctor neque vitae. Lorem mollis aliquam ut porttitor. Ac orci phasellus egestas tellus. Neque laoreet suspendisse interdum consectetur libero id. Egestas sed sed risus pretium quam vulputate. Aliquam ultrices sagittis orci a. Ut ornare lectus sit amet. Interdum velit laoreet id donec ultrices tincidunt. Dui sapien eget mi proin sed libero enim sed faucibus.',
        },
      ],
    },
    {
      subHeading: 'SUB Header',
      lines: [
        {
          label:
            'Lorem ipsum dolorLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Facilisis gravida neque convallis a cras semper auctor neque vitae. Lorem mollis aliquam ut porttitor. Ac orci phasellus egestas tellus. Neque laoreet suspendisse interdum consectetur libero id. Egestas sed sed risus pretium quam vulputate. Aliquam ultrices sagittis orci a. Ut ornare lectus sit amet. Interdum velit laoreet id donec ultrices tincidunt. Dui sapien eget mi proin sed libero enim sed faucibus.',
        },
      ],
    },
    {
      subHeading: 'SUB Header',
      // bulletList: true,
      numberedList: true,

      lines: [
        {
          label: 'Patients presenting with cardiac arrest',
          style: {
            fontWeight: 'bold',
          },
        },
        {
          label: 'Patients requiring cardiac defibrillation',
        },
        {
          label: 'Patients presenting with Return of Spontaneous Circulation',
        },
      ],
    },
  ],
  textBlockDataTwo = [
    {
      subHeading: 'SUB Header',
      lines: [
        {
          label:
            'Lorem ipsum dolorLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Facilisis gravida neque convallis a cras semper auctor neque vitae. Lorem mollis aliquam ut porttitor. Ac orci phasellus egestas tellus. Neque laoreet suspendisse interdum consectetur libero id. Egestas sed sed risus pretium quam vulputate. Aliquam ultrices sagittis orci a. Ut ornare lectus sit amet. Interdum velit laoreet id donec ultrices tincidunt. Dui sapien eget mi proin sed libero enim sed faucibus.',
        },
      ],
    },
    {
      subHeading: 'SUB Header',
      bulletList: true,

      lines: [
        {
          label: 'Patients presenting with cardiac arrest',
          style: {
            fontWeight: 'bold',
          },
        },
        {
          label: 'Patients requiring cardiac defibrillation',
        },
        {
          label: 'Patients presenting with Return of Spontaneous Circulation',
        },
      ],
    },
  ]

describe('CDS TextBlock Component', () => {
  test('Render TextBlock without Crash', () => {
    render(
      <CDSTextBlock
        header={
          'MACE CDS is intended for use with Emergency Department (ED) patients 22 years and over. The application is not intended for the following patient populations:'
        }
        totalColumns={3}
        backgroundColor={'#e0e0e0'}
        columns={textBlockData}
      />
    )

    const orgName = screen.getByText(/Patients presenting with cardiac arrest/i)
    expect(orgName).toBeInTheDocument()
  })

  test('Render TextBlock with 3 Columns & Numbered List', () => {
    render(
      <CDSTextBlock
        header={
          'MACE CDS is intended for use with Emergency Department (ED) patients 22 years and over. The application is not intended for the following patient populations:'
        }
        totalColumns={3}
        backgroundColor={'#e0e0e0'}
        columns={textBlockData}
      />
    )

    const orgName = screen.getByText(/Patients presenting with cardiac arrest/i)
    expect(orgName).toBeInTheDocument()
  })

  test('Render TextBlock with 2 Columns & Bullet List', () => {
    render(
      <CDSTextBlock
        header={
          'MACE CDS is intended for use with Emergency Department (ED) patients 22 years and over. The application is not intended for the following patient populations:'
        }
        totalColumns={2}
        backgroundColor={'#e0e0e0'}
        columns={textBlockDataTwo}
      />
    )

    const orgName = screen.getByText(/Patients presenting with cardiac arrest/i)
    expect(orgName).toBeInTheDocument()
  })
})
