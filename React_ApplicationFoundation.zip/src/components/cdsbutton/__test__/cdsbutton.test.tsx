import React from 'react';
import { render, screen } from '@testing-library/react';
import CDSButton from '../../cdsbutton/cdsbutton';
import userEvent from '@testing-library/user-event';

const handleCDSButtonClick = () => {
    console.log('Click Event')
}
test('renders button', () => {
    render(<CDSButton buttonText='CDS Button App' onClickevent={handleCDSButtonClick} />);
    const linkElement = screen.getByText(/CDS Button App/i);
    expect(linkElement).toBeInTheDocument();
});
test('renders Primary button', () => {
    render(<CDSButton buttonText='CDS Button' variant='contained' onClickevent={handleCDSButtonClick} />);
    const linkElement = screen.getByText(/CDS Button/i).closest("button");
    expect(linkElement?.className.split(' ').includes("MuiButton-contained")).toBe(true);
});

test('renders Secondary button', () => {
    render(<CDSButton buttonText='CDS Button' variant='outlined' onClickevent={handleCDSButtonClick} />);
    const linkElement = screen.getByText(/CDS Button/i).closest('button');
    expect(linkElement?.className.split(' ').includes("MuiButton-outlined")).toBe(true);
});

test('renders Tertiary button', () => {
    render(<CDSButton buttonText='CDS Button' variant='text' onClickevent={handleCDSButtonClick} />);
    const linkElement = screen.getByText(/CDS Button/i).closest('button');
    expect(linkElement?.className.split(' ').includes("MuiButton-text")).toBe(true);
})

test('renders disabled button', () => {
    render(<CDSButton buttonText='CDS Button' variant='text' disabled={true} onClickevent={handleCDSButtonClick} />);
    const linkElement = screen.getByText(/CDS Button/i);
    expect(linkElement).toBeDisabled;
})
test('Click event Fired', () => {
    render(<CDSButton buttonText='CDS Button' variant='text' disabled={false} onClickevent={handleCDSButtonClick} />);
    const linkElement = screen.getByText(/CDS Button/i);
    userEvent.click(screen.getByRole('button', { name: /CDS Button/i }));
    expect(linkElement).toHaveBeenCalled;
})

test('renders tooltip for button', () => {
    render(<CDSButton toolTip='CDS Tooltip' buttonText='CDS Button' variant='text' disabled={false} onClickevent={handleCDSButtonClick} />);
    const linkElement = screen.getByText(/CDS Button/i);
    userEvent.hover(screen.getByTitle('CDS Tooltip'));
    expect(linkElement).toHaveBeenCalled;
})
