import React from 'react';
import { ComponentStory, ComponentMeta } from '@storybook/react';
import CDSButton from './cdsbutton';


export default {
    title: 'CDS Button',
    id : 'cdsButton',
    component: CDSButton,
    argTypes: {
        buttonText: 'AMI',
        width: '30%',
        toolTip: 'Button Tooltip',
        justifyContent: {
            options: ['Left', 'Right', 'Center'],
            control: { type: 'radio' },
        },
        ButtonTextalignment: {
            options: ['Left', 'Right', 'Center'],
            control: { type: 'radio' },
        },
        variant: {
            options: ['text', 'outlined', 'contained'],
            control: { type: 'radio' },
        },
        icon: {
            options: ['Help', 'Addicon', 'AddTask', 'checkIcon', 'Trash', 'Highlight', 'clipboard', 'Rotating Arrow', 'Close', 'Patient', 'Arrow Diagonal Right square', 'CaretUp', 'CaretDown', 'Missing', 'warning', 'Alert', 'Error', 'Arrow Down', 'Arrow Up', 'Pencil', 'Chevron Up', 'Chevron Down'],
            control: { type: 'select' },
        },

        disabled: { control: 'boolean' },
        svgiconpath:"M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z",
        startIcon: { control: 'boolean' },
        endIcon: { control: 'boolean' },
        iconButton: { control: 'boolean' },
        onClickevent: { action: 'clicked' },
        textColor: { control: 'color' },
        btnColor: { control: 'color' },
        customStyle: {},
        requiredStyleIcon: {
            width: "38",
            height: "38",
            viewBox: "0 0 38 38",
            fill: "none",
        },
       customStyleIcon: {
        },
        parameters: {
            actions: {
                handles: ['mouseover', 'click .btn'],
            },
        },
    },
} as unknown as ComponentMeta<typeof CDSButton>

const Template: ComponentStory<typeof CDSButton> = (args) => (
    <CDSButton {...args} />
)

export const button = Template.bind({})
button.args = {
    customClassName: "customClassName",
    customIdName: "cdsButton",
    buttonText: 'CDS Button',
    variant: 'outlined',
    icon: 'Addicon',
    disabled: false,
    startIcon: false,
    endIcon: false,
    iconButton: false,
    width: '30%',
    justifyContent: 'Left',
    toolTip: 'Button Tooltip',
    ButtonTextalignment: 'left',
    customStyle: {},
    svgiconpath:"M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z",
    requiredStyleIcon: {
        width: "38",
        height: "38",
        viewBox: "0 0 38 38",
        fill: "none",
    },
    customStyleIcon: {
        
    },

}



