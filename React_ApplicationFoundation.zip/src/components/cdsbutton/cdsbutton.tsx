import React, { FunctionComponent } from 'react';
import { Button, ButtonProps, SvgIcon } from '@material-ui/core';
import './cdsbutton';
import styled from 'styled-components'
import Box from '@material-ui/core/Box';

type ButtonBaseProps = Pick<ButtonProps, "variant" | "disabled">
export interface CDSButtonProps extends ButtonBaseProps {
  id?:string
  customClassName?: string
  customIdName?: string
  buttonText: string
  startIcon?: boolean
  endIcon?: boolean
  iconButton?: boolean
  onClickevent: () => void
  width?: string
  justifyContent?: string
  ButtonTextalignment?: string
  toolTip?: string
  icon?: string
  textColor?: string
  btnColor?: string
  customStyle?: {}
  requiredStyleIcon?: {
    width?:string
    height?:string
    viewBox?:string 
    fill?:string
  }
  customStyleIcon?: {
   
  }
  svgiconpath?: string

}
const MUICDSButton = styled(Button)`
    width:${(props: CDSButtonProps) =>
    props.width ? props.width : '30%'};
    border-Color:${(props: CDSButtonProps) =>
    props.btnColor ? props.btnColor : 'red'};
  
    :hover{
      opacity:0.2;
      box-shadow: 5px 5px 5px #808080;
    };
    overflow-wrap: anywhere;
    
 `
const ButtonBox = styled(Box)`
    display:flex;
    justifyContent:${(props: CDSButtonProps) =>
    props.justifyContent ? (props.justifyContent === 'Left' ? 'flex-start' : (props.justifyContent === 'Right' ? 'flex-end' : 'center')) : 'flex-start'};
 `

//<span class="IconTextBox" style="background: rgb(255, 202, 44); font-weight: 700; padding: 0px 7px; border-radius: 50%;">?</span>
const CDSButton: FunctionComponent<CDSButtonProps> = (props: CDSButtonProps) => {

  return (
    <ButtonBox  {...props} style={{ width: '100%' }}>
      <MUICDSButton title={props.toolTip} onClick={props.onClickevent} id={props.customIdName} className={props.customClassName} {...props} style={{...props.customStyle, textTransform: 'none', color: props.textColor, backgroundColor: props.variant === 'text' || props.variant === 'outlined' ? 'transparent' : props.btnColor, borderColor: props.variant === 'outlined' ? props.btnColor : props.variant === 'text' ? 'transparent' : props.btnColor, justifyContent: props.ButtonTextalignment }}>
        {props.startIcon ?
          <SvgIcon style={{...props.customStyleIcon}} {...props.requiredStyleIcon}>
            <path d={props.svgiconpath} />
          </SvgIcon> : <></>}
        {props.iconButton ? <SvgIcon style={{...props.customStyleIcon}} {...props.requiredStyleIcon}>
          <path d={props.svgiconpath} />
        </SvgIcon> : props.buttonText}
        {props.endIcon ?
          <SvgIcon style={{...props.customStyleIcon}} {...props.requiredStyleIcon}>
            <path d={props.svgiconpath} />
          </SvgIcon> : <></>}
      </MUICDSButton>
    </ButtonBox>


  )
}
export default CDSButton;


