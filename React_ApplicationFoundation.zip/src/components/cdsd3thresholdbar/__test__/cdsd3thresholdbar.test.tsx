import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import React from 'react';
import { render } from '@testing-library/react';
import CDSThresholdBar from '../cdsd3thresholdbar';


test('render scalebar', () => {

    const { container } = render(<CDSThresholdBar
        id={'cdsThresholdBar'}
        numberBlocks={10}
        highColor={'#ffe6e6'}
        lowColor={'#D2E1F1'}
        intermediatecolor={'#ECECEC'}
        lowRangeMin={1}
        lowRangeMax={3}
        intermRangeMin={4}
        intermRangeMax={6}
        highRangeMin={7}
        highRangeMax={10}
        pointerValue={2}
        lowPointerColor={'#1C68B8'}
        highPointerColor={'#AC2419'}
        intermediatePointercolor={'#CACACA'} startPoint={1} />);

    const path = container.querySelector("path");
      
    expect(path?.getAttribute("d")).not.toMatch(/NaN|undefined/);
    expect(path?.getAttribute("d")).not.toBe("");
});
test('render scalebar with x parameter', () => {

    const { container } = render(<CDSThresholdBar
        id={'cdsThresholdBar'}
        numberBlocks={10}
        highColor={'#ffe6e6'}
        lowColor={'#D2E1F1'}
        intermediatecolor={'#ECECEC'}
        lowRangeMin={1}
        lowRangeMax={3}
        intermRangeMin={4}
        intermRangeMax={6}
        highRangeMin={7}
        highRangeMax={10}
        pointerValue={2}
        lowPointerColor={'#1C68B8'}
        highPointerColor={'#AC2419'}
        intermediatePointercolor={'#CACACA'} startPoint={1} />);

    const path = container.querySelector("rect");
      
    expect(path?.getAttribute("x")).toBe("74");
});
test('render scalebar with y parameter', () => {

    const { container } = render(<CDSThresholdBar
        id={'cdsThresholdBar'}
        numberBlocks={10}
        highColor={'#ffe6e6'}
        lowColor={'#D2E1F1'}
        intermediatecolor={'#ECECEC'}
        lowRangeMin={1}
        lowRangeMax={3}
        intermRangeMin={4}
        intermRangeMax={6}
        highRangeMin={7}
        highRangeMax={10}
        pointerValue={2}
        lowPointerColor={'#1C68B8'}
        highPointerColor={'#AC2419'}
        intermediatePointercolor={'#CACACA'} startPoint={1} />);

    const path = container.querySelector("rect");
      
    expect(path?.getAttribute("y")).toBe("38");
});
test('render scalebar with styles for text svg', () => {

    const { container } = render(<CDSThresholdBar
        id={'cdsThresholdBar'}
        numberBlocks={10}
        highColor={'#ffe6e6'}
        lowColor={'#D2E1F1'}
        intermediatecolor={'#ECECEC'}
        lowRangeMin={1}
        lowRangeMax={3}
        intermRangeMin={4}
        intermRangeMax={6}
        highRangeMin={7}
        highRangeMax={10}
        pointerValue={2}
        lowPointerColor={'#1C68B8'}
        highPointerColor={'#AC2419'}
        intermediatePointercolor={'#CACACA'} startPoint={1} />);

    const path = container.querySelector("text");
    console.log(path?.style)
      
    expect(path).toHaveStyle("text-anchor:middle");
    expect(path).toHaveStyle("font-size:10px");
})
test('render scalebar with styles for box', () => {

    const { container } = render(<CDSThresholdBar
        id={'cdsThresholdBar'}
        numberBlocks={10}
        highColor={'#ffe6e6'}
        lowColor={'#D2E1F1'}
        intermediatecolor={'#ECECEC'}
        lowRangeMin={1}
        lowRangeMax={3}
        intermRangeMin={4}
        intermRangeMax={6}
        highRangeMin={7}
        highRangeMax={10}
        pointerValue={2}
        lowPointerColor={'#1C68B8'}
        highPointerColor={'#AC2419'}
        intermediatePointercolor={'#CACACA'} startPoint={1} />);

    const path = container.querySelector("rect");
    console.log(path?.style)
      
    expect(path).not.toHaveStyle("text-anchor:middle");
    expect(path).not.toHaveStyle("font-size:15px");
    expect(path).toHaveStyle("fill:#D2E1F1");
})


