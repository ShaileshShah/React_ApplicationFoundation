import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import React, { useEffect, useRef, FunctionComponent } from 'react';
import * as d3 from "d3";
import styled from 'styled-components';
//import { useTranslation } from 'react-i18next';
import { Box } from '@material-ui/core';

//Needed for Advnance PBI story
// interface Rangeparmeter {
//     label: string;
//     range: { min: string, max: string }
//     color: string;
// }
import { THRESHOLDBAR } from '../utilities/constants';

export interface CDSThresholdBarProps {
    id:string
    numberBlocks: number
    lowPointerColor: string
    highPointerColor: string
    intermediatePointercolor: string
    lowColor: string
    highColor: string
    intermediatecolor: string
    lowRangeMin: number
    lowRangeMax: number
    intermRangeMin: number
    intermRangeMax: number
    highRangeMin: number
    highRangeMax: number
    pointerValue: number
    startPoint: number
    rangeMax?: number
    rangeMin?: number
    sizeOfPointer?: number
    sizeOfArc?: number
    radiusOfArc?: number
    verticalPositionOfArc?: number
    verticalPositionOfTriangle?: number
    positionOfNumbers?: number
    aspectWidth?:number

}
const CustomBox = styled(Box)`

 `
const CDSThresholdBar: FunctionComponent<CDSThresholdBarProps> = (props: CDSThresholdBarProps) => {
    //const { t } = useTranslation(['home', 'main']);
    const svgRef = useRef<SVGSVGElement | null>(null);

    let Max = props.rangeMax ? props.rangeMax : 10;
    let Min = props.rangeMin ? props.rangeMin : 1;


    const data = (max: number | any, min: number | any) => {
        let dataArray = []
        for (var i = min; i <= max; i++) {
            dataArray[i - 1] = i;
        }
        return dataArray;
    }
    useEffect(() => {
        let arcSize=props.sizeOfArc?props.sizeOfArc:500,
        arcRadius=props.radiusOfArc?props.radiusOfArc:0.25,
        triangleSize=props.sizeOfPointer?props.sizeOfPointer:100,
        trianglePosition=props.verticalPositionOfTriangle?props.verticalPositionOfTriangle:28,
        arcPosition=props.verticalPositionOfArc?props.verticalPositionOfArc:38,
        numberPosition=props.positionOfNumbers?props.positionOfNumbers:40,
        widthAspect=props.aspectWidth?props.aspectWidth:80;

        var customShapeCircle = {
            draw: function (context: any, size: any) {
                let r = Math.sqrt(arcRadius * size / Math.PI);
                let orgin = (1 * r) / (2 * Math.PI); //the orgin of the circle, not of the symbol
                context.arc(0, -orgin, r, Math.PI, 2 * Math.PI, true);
                context.closePath();
            }
        }

        var customCircle = d3.symbol().type(customShapeCircle).size(arcSize);
        const svg = d3.select(svgRef.current);

        svg
            .selectAll('rect')
            .data(data(Max, Min))
            .enter()
            .append('rect')
            .attr('x', (i) => ((i + props.startPoint) * (widthAspect+2)) - 90)
            .attr('y', 38)
            .attr('width', widthAspect) // distance btw box & width of box
            .attr('height', 26)


            //d refers to Scale Data from 1 to 10
            //d<4--low range
            //d>5-- high range
            //else--  medium range
            .style('fill', function (d) {
                return d < props.lowRangeMax + 1
                    ? (d === props.pointerValue && props.pointerValue < props.lowRangeMax + 1 ? props.lowPointerColor : props.lowColor)
                    : d > props.intermRangeMax
                        ? (d === props.pointerValue && props.pointerValue > props.intermRangeMax ? props.highPointerColor : props.highColor)
                        : d > props.lowRangeMax && d < props.highRangeMin
                            ? (d === props.pointerValue && props.pointerValue > props.lowRangeMax && props.pointerValue < props.highRangeMin ? props.intermediatePointercolor : props.intermediatecolor)
                            : props.intermediatecolor
            });

        svg
            .selectAll('text')
            .data(data(Max, Min))
            .enter()
            .append('text')
            .text((d) => d)
            .attr('x', (i) => (((i + props.startPoint) * (widthAspect+2)) - 90) + numberPosition) //45 postion of text box horizontally
            .attr('y', 56)
            .attr('font-weight', function (d) {
                return d < props.lowRangeMax + 1
                    ? (d === props.pointerValue && props.pointerValue < props.lowRangeMax + 1 ? THRESHOLDBAR.fontWeight_Pointer : THRESHOLDBAR.fontWeight_blockText)
                    : d > props.intermRangeMax
                        ? (d === props.pointerValue && props.pointerValue > props.intermRangeMax ? THRESHOLDBAR.fontWeight_Pointer : THRESHOLDBAR.fontWeight_blockText)
                        : d > props.lowRangeMax && d < props.highRangeMin
                            ? (d === props.pointerValue && props.pointerValue > props.lowRangeMax && props.pointerValue < props.highRangeMin ? THRESHOLDBAR.fontWeight_Pointer : THRESHOLDBAR.fontWeight_blockText)
                            : THRESHOLDBAR.fontWeight_Pointer

            })
            .style('text-anchor', 'middle')
            .style('font-size', function (d) {

                return d < props.lowRangeMax + 1
                    ? (d === props.pointerValue && props.pointerValue < props.lowRangeMax + 1 ? THRESHOLDBAR.fontSize_Pointer : THRESHOLDBAR.fontSize_blockText)
                    : d > props.intermRangeMax
                        ? (d === props.pointerValue && props.pointerValue > props.intermRangeMax ? THRESHOLDBAR.fontSize_Pointer : THRESHOLDBAR.fontSize_blockText)
                        : d > props.lowRangeMax && d < props.highRangeMin
                            ? (d === props.pointerValue && props.pointerValue > props.lowRangeMax && props.pointerValue < props.highRangeMin ? THRESHOLDBAR.fontSize_Pointer : THRESHOLDBAR.fontSize_blockText)
                            : THRESHOLDBAR.fontSize_blockText
            })
            .style('fill', function (d) {

                return d < props.lowRangeMax + 1
                    ? (d === props.pointerValue && props.pointerValue < props.lowRangeMax + 1 ? THRESHOLDBAR.fontcolor_Pointer : THRESHOLDBAR.fontcolor_blockText)
                    : d > props.intermRangeMax
                        ? (d === props.pointerValue && props.pointerValue > props.intermRangeMax ? THRESHOLDBAR.fontcolor_Pointer : THRESHOLDBAR.fontcolor_blockText)
                        : d > props.lowRangeMax && d < props.highRangeMin
                            ? (d === props.pointerValue && props.pointerValue > props.lowRangeMax && props.pointerValue < props.highRangeMin ?THRESHOLDBAR.fontcolor_IndeterminatePointer: THRESHOLDBAR.fontcolor_blockText)
                            : THRESHOLDBAR.fontcolor_blockText

            });


            svg
            .append("text")
            .attr("y", 100)
            .attr("x", ((props.lowRangeMin + props.startPoint) * (widthAspect+2)) - 90)
            .attr("text-anchor", "start")
            .attr("fill", props.lowPointerColor)
            .attr("font-size", "12px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 700)
            .text('Low');

        svg
            .append("text")
            .attr("y", 120)
            .attr("x", ((props.lowRangeMin + props.startPoint) * (widthAspect+2)) - 90)
            .attr("fill", "#B6BCC1")
            .attr("font-size", "8px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 300)
            .text('Less than 0.5% chance of developing');


        svg
            .append("text")
            .attr("y", 130)
            .attr("x", ((props.lowRangeMin + props.startPoint) * (widthAspect+2)) - 90)
            .attr("fill", "#B6BCC1")
            .attr("font-size", "8px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 300)
            .text('MACE within 30 days of discharge');

        //Text data of intermediate or Medium
        svg
            .append("text")
            .attr("y", 100)
            .attr("x", ((props.intermRangeMin + props.startPoint) * (widthAspect+2)) - 90) //d {1,2,3..} formula to x-point =(d-1)*100
            .attr("text-anchor", "start")
            .attr("fill", '#3A4651')
            .attr("font-size", "12px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 700)
            .text("Indeterminate");

        svg
            .append("text")
            .attr("y", 120)
            .attr("x", ((props.intermRangeMin + props.startPoint) * (widthAspect+2)) - 90)
            .attr("fill", "#B6BCC1")
            .attr("font-size", "8px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 300)
            .text('Between 1% - 2% chance of developing');

        svg
            .append("text")
            .attr("y", 130)
            .attr("x", ((props.intermRangeMin + props.startPoint) * (widthAspect+2)) - 90)
            .attr("fill", "#B6BCC1")
            .attr("font-size", "8px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 300)
            .text('MACE within 30 days of discharge');

        //Text data of High
        svg
            .append("text")
            .attr("y", 100)
            .attr("x", ((props.highRangeMax + props.startPoint + 1) * (widthAspect+2)) - 100) //d {1,2,3..} formula to x-point =(d-1)*100
            .attr("text-anchor", "end")
            .attr("fill", props.highPointerColor)
            .attr('font-size', '12px')
            .attr('font-family', 'Arial')
            .attr('font-weight', 700)
            .text("High");

        svg
            .append("text")
            .attr("y", 120)
            .attr("x", ((props.highRangeMax + props.startPoint + 1) * (widthAspect+2)) - 100)
            .attr("text-anchor", "end")
            .attr("fill", "#B6BCC1")
            .attr("font-size", "8px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 300)
            .text('Greater than 2% chance of developing');

        svg
            .append("text")
            .attr("y", 130)
            .attr("x", ((props.highRangeMax + props.startPoint + 1) * (widthAspect+2)) - 100)
            .attr("text-anchor", "end")
            .attr("fill", "#B6BCC1")
            .attr("font-size", "8px")
            .attr('font-family', 'Arial')
            .attr('font-weight', 300)
            .text('MACE within 30 days of discharge');

            

        d3.selectAll('svg')
            .append('path')
            .attr("d", customCircle)
            .attr('transform', `translate(${(props.pointerValue + props.startPoint) * (widthAspect+2) - 90 + numberPosition},${(arcPosition)})`)
            .style('fill', 'white')

        d3.selectAll('svg')
            .append('path')
            .attr('d', d3.symbol().type(d3.symbolTriangle).size(triangleSize))
            .attr("id", "triangle")
            .attr("stroke", function () {
                return props.pointerValue < props.intermRangeMin
                    ? props.lowPointerColor
                    : props.pointerValue > props.intermRangeMax && props.pointerValue <= props.highRangeMax
                        ? props.highPointerColor : props.intermediatePointercolor;
            })
            .attr("stroke-width", "6px")
            .attr("stroke-linejoin", "round")
            .attr('stroke-linecap', 'round')
            .attr('transform', `translate(${(props.pointerValue + props.startPoint) * (widthAspect+2) - 90 + numberPosition},${(trianglePosition)}) rotate(180)`)
            .style('fill', function () {
                return props.pointerValue < props.intermRangeMin
                    ? props.lowPointerColor
                    : props.pointerValue > props.intermRangeMax && props.pointerValue <= props.highRangeMax
                        ? props.highPointerColor
                        : props.intermediatePointercolor

            });



    }, []);


    return (
        <CustomBox id="scalebar" 
        style={{ marginLeft: '0%', marginRight: '0%' }}
        >
            <svg ref={svgRef} width={"auto"} height={"auto"}></svg>

            <div></div>
        </CustomBox>
        )
}
export default CDSThresholdBar;