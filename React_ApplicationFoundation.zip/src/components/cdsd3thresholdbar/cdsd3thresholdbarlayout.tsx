import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import React from 'react';
import CDSThresholdBar from './cdsd3thresholdbar';
import { Box } from '@material-ui/core';


const CDSThresholdbarLayout = () => {
    return (<Box>

        <CDSThresholdBar
            id={'cdsThresholdBar'}
            numberBlocks={10}
            highColor={'#ffe6e6'}
            lowColor={'#D2E1F1'}
            intermediatecolor={'#ECECEC'}
            lowRangeMin={1}
            lowRangeMax={4}
            intermRangeMin={5}
            intermRangeMax={6}
            highRangeMin={7}
            highRangeMax={10}
            pointerValue={5}
            lowPointerColor={'#1C68B8'}
            highPointerColor={'#AC2419'}
            intermediatePointercolor={'#CACACA'} startPoint={0.5} />

        {/* <CDSThresholdBar
            id={'cdsThresholdBar'}
            numberBlocks={10}
            highColor={'#ffe6e6'}
            lowColor={'#D2E1F1'}
            intermediatecolor={'#ECECEC'}
            lowRangeMin={1}
            lowRangeMax={2}
            intermRangeMin={3}
            intermRangeMax={6}
            highRangeMin={7}
            highRangeMax={10}
            pointerValue={2}
            lowPointerColor={'#1C68B8'}
            highPointerColor={'#AC2419'}
            intermediatePointercolor={'#CACACA'} /> */}

         {/* <CDSThresholdBar
            id={'cdsThresholdBar'}
            numberBlocks={10}
            highColor={'#ffe6e6'}
            lowColor={'#D2E1F1'}
            intermediatecolor={'#FFF4D5'}
            lowRangeMin={1}
            lowRangeMax={3}
            intermRangeMin={4}
            intermRangeMax={6}
            highRangeMin={7}
            highRangeMax={10}
            pointerValue={4}
            lowPointerColor={'#1C68B8'}
            highPointerColor={'#AC2419'}
            intermediatePointercolor={'#FFCA2C'} />  */}
    </Box>
    )
}
export default CDSThresholdbarLayout;