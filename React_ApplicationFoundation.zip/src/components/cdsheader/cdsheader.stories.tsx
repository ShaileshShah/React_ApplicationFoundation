import React from 'react'
import { ComponentStory, ComponentMeta } from '@storybook/react'
import CDSHeader from './cdsheader'

export default {
  id:'cdsHeader',
  title: 'CDS Header',
  component: CDSHeader,
  argTypes: {
    background: { control: 'color' },
    title: 'AMI',
    subTitle: 'CDS',
    description: 'cds solutions',
  },
} as unknown as ComponentMeta<typeof CDSHeader>

const Template: ComponentStory<typeof CDSHeader> = (args) => (
  <CDSHeader {...args} />
)

export const header = Template.bind({})
header.args = {
  id:'cdsHeader',
  title: 'AMI',
  subTitle: 'CDS',
  description: 'cds solutions',
}
