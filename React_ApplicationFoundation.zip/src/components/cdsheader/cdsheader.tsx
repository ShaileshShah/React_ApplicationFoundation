import React from 'react'
import CardHeader from '@material-ui/core/CardHeader'
import { Card } from '@material-ui/core'
import styled from 'styled-components'
import './cdsheader'
import { useTranslation } from 'react-i18next'

type CustomCardHeaderProps = {
  id?:string
  title: string
  subTitle?: string
  background?: string
  description?: string
}


const CustomCardHeader = styled(CardHeader)`
  background-color: ${(props: CustomCardHeaderProps) =>
    props.background ? props.background : '#20b2aa'};

  :hover {
    color: #2e8b57;
  }
  & .MuiSlider-thumb {
    border-radius: 1px;
  }
`

/**
 * CDSHeader Props
 */
type CDSHeaderProps = {
  id:string
  title: string
  subTitle?: string
  background?: string
  description?: string
  headerStyles?:string
}


const CDSHeader = ({
  id,
  title,
  subTitle,
  description,
  background,
}: CDSHeaderProps) => {
  const { t } = useTranslation(['home', 'main']);
  return (
    <Card 
    style={{ minWidth: 275 }}
    className="header-defaults">
      <CustomCardHeader
        id={id}
        title={t(title, { ns: ['main', 'home'] })} 
        subheader={subTitle}
        background={background}
      >
        {description}
      </CustomCardHeader>
    </Card>
  )
}

export default CDSHeader
