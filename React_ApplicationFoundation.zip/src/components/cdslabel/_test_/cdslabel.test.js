import { render, screen , component} from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Cdslabel from '../cdslabel.tsx'



const labelData = {
  label: "Name",  
}

const labelVarient = {
  State:"RiskScore",
  RiskScore:"high",
  OtherState:"",
  Size:"BannerSize"
}

const customStyle = {
  color:"red",
  background:"yellow",
  padding:"15px",
  borderRadius:"10px"
}



describe('Cdslabel', () => {
  it('Renders Cdslabel Exist', () => {
    const handleChange = jest.fn();
    render(
      <Cdslabel field={labelData} varient={labelVarient} customStyle={customStyle} customClass="customClass" />
    );
    const cdsLabelComponent = screen.getByText('Name');
    expect(cdsLabelComponent).toBeInTheDocument();
  });

  it('Renders Cdslabel style property', () => {
    const handleChange = jest.fn();
    render(
      <Cdslabel field={labelData} varient={labelVarient} customStyle={customStyle} customClass="customClass" />
    );
    const cdsLabelComponent = screen.getByText('Name');
    expect(cdsLabelComponent).toHaveStyle("color:red");
  });

  it('Renders Cdslabel custom Class property', () => {
    const handleChange = jest.fn();
    render(
      <Cdslabel field={labelData} varient={labelVarient} customStyle={customStyle} customClass="customClass" />
    );
    const cdsLabelComponent = screen.getByText('Name');
    console.log(cdsLabelComponent)
    expect(cdsLabelComponent).toHaveClass("high");
  });
});
 