import React from 'react'
import { ComponentStory, ComponentMeta } from '@storybook/react'
import Cdslabel from './cdslabel'


export default {
    title: 'CDS Label',
    id:'cdsLabel',
    component: Cdslabel,
    argTypes: {
        field: {
            label: { type: 'string' }
        },
        varient: {
            State: { type: 'string' },
            RiskScore: { type: 'string' },
            OtherState: { type: 'string' },
            Size: { type: 'string' },
        },
        customStyle: {}
    },
} as unknown as ComponentMeta<typeof Cdslabel>

const Template: ComponentStory<typeof Cdslabel> = (args) => (
    <Cdslabel {...args} />
)

export const label = Template.bind({})
label.args = {
    id:'cdsLabel',
    field: {
        label: "Application Name"
    },
    varient: {
        State: "RiskScore",
        RiskScore: "high",
        OtherState: "state1",
        InputState: "NormalState",
        Size: "BannerSize"
    },
    customStyle: {},
    customClass:""
}

