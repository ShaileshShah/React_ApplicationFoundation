import React from 'react';
import { Typography } from '@material-ui/core';
import "./cdslabel.css"


type propstype = {
    id?:string
    field?: {
        label?: string
    }
    varient?: {
        State?: string
        RiskScore?: string
        OtherState?: string
        InputState?:string
        Size?: string
    }
    customStyle?: {}
    customClass?:string
    required?:boolean
}

const cdslabel = (props: propstype) => {
    const { field, varient, customStyle,customClass } = props;

    return (
        <div>
            <Typography >
                <span id='cdsLabel' className={`${customClass} ${varient?.RiskScore?.trim().length !== 0 && varient?.State === "RiskScore" ? varient?.RiskScore : ""} ${varient?.OtherState?.trim().length !== 0 && varient?.State === "OtherState" ? varient?.OtherState : ""} ${varient?.InputState?.trim().length !== 0 && varient?.State === "InputState" ? varient?.InputState : ""} ${varient?.Size}`} style={customStyle}>{field?.label} {props.required && props.varient?.State === "InputState"?<span style={{color:"red"}}>&nbsp;*&nbsp;</span>:<span></span>}</span> 
            </Typography>

        </div>
    );
};

export default cdslabel;
