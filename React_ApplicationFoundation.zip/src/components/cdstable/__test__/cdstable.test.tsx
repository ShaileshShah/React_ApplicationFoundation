import React from 'react';
import { render, cleanup } from '@testing-library/react';
import CdsTable from '../cdstable';

afterEach(cleanup);


////////////////////////////////// BAISC TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderBasic = {
  //  border:"1px solid purple",
}

const customTableStylesBodyBasic = {
  // border:"1px solid purple"
}

const RowDataBasic = [
  {
    "id": 1,
    "#": {
      "value": "1",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Names",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test firstColumn",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 2,
    "#": {
      "value": "2",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 3,
    "#": {
      "value": "3",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 4,
    "#": {
      "value": "4",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 5,
    "#": {
      "value": "5",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
];

const columnsDataBasic = [
  { field: "#", header: "#", width: "50px", CustomStyle: { textAlign: "left" }, className: "ThClass NewRow" },
  { field: "RiskFactor", header: "RiskFactor", width: "", CustomStyle: { textAlign: "left" }, className: "ThClass" },
  { field: "PatientValue", header: "PatientValue", width: "", CustomStyle: { textAlign: "left" }, className: "ThClass" },
  { field: "%", header: "%", width: "", CustomStyle: { textAlign: "left" }, className: "ThClass" },
  { field: "Contribution", header: "Contribution", width: "50px", CustomStyle: { textAlign: "right" }, className: "ThClass", },
];


test('renders to check column header exists', () => {
  const { container } = render(<CdsTable row={RowDataBasic} columns={columnsDataBasic} type="" width="100%" customtablestylesheader={customTableStylesHeaderBasic} customtablestylesbody={customTableStylesBodyBasic} />);
  const Item = container.getElementsByClassName('ThClass');
  expect(Item.length).toBe(5);
});

it('renders to check Class adding to table', () => {
  const { container } = render(<CdsTable row={RowDataBasic} columns={columnsDataBasic} type="" width="100%" customtablestylesheader={customTableStylesHeaderBasic} customtablestylesbody={customTableStylesBodyBasic} />);
  const cdsTableComponent = container.getElementsByClassName('firstColumn');
  expect(cdsTableComponent[0]).toHaveClass("firstColumn");
});

it('renders to check row counts', () => {
  const { container } = render(<CdsTable row={RowDataBasic} columns={columnsDataBasic} type="" width="100%" customtablestylesheader={customTableStylesHeaderBasic} customtablestylesbody={customTableStylesBodyBasic} />);
  const cdsTableComponent = container.getElementsByTagName('tr');
  expect(cdsTableComponent.length).toBeGreaterThanOrEqual(5);
});

it('renders to Negative Scenario check row counts', () => {
  const { container } = render(<CdsTable row={RowDataBasic} columns={columnsDataBasic} type="" width="100%" customtablestylesheader={customTableStylesHeaderBasic} customtablestylesbody={customTableStylesBodyBasic} />);
  const cdsTableComponent = container.getElementsByTagName('tr');
  expect(cdsTableComponent.length).not.toBeLessThan(5);
});

it('renders to check Styles addding dynamically', () => {
  const { container } = render(<CdsTable row={RowDataBasic} columns={columnsDataBasic} type="" width="100%" customtablestylesheader={customTableStylesHeaderBasic} customtablestylesbody={customTableStylesBodyBasic} />);
  const cdsTableComponent = container.getElementsByClassName('NewRow');
  expect(cdsTableComponent[0]).toHaveStyle({ "width": "50px" });
});

it('renders to check negative Styles addding dynamically', () => {
  const { container } = render(<CdsTable row={RowDataBasic} columns={columnsDataBasic} type="" width="100%" customtablestylesheader={customTableStylesHeaderBasic} customtablestylesbody={customTableStylesBodyBasic} />);
  const cdsTableComponent = container.getElementsByClassName('NewRow');
  expect(cdsTableComponent[0]).not.toHaveStyle({ "width": "20px" });
});

it('Clicking the Negative Scenarios for first Values', () => {
  const { container } = render(<CdsTable row={RowDataBasic} columns={columnsDataBasic} type="" width="100%" customtablestylesheader={customTableStylesHeaderBasic} customtablestylesbody={customTableStylesBodyBasic} />);
  const cdsTableComponent = container.getElementsByClassName('firstColumn');
  expect(cdsTableComponent[0].innerHTML === "Factor").toBeFalsy();
});


////////////////////////////////// BAISC TABLE PROPS DATA ENDS ?///////////////////////



////////////////////////////////// LAB TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderLabTable = {
  //  border:"1px solid purple",
}

const customTableStylesBodyLabTable = {
  // border:"1px solid purple"
}
const RowDataLabTable = [
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "ssss",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "firstClass",
    },
    "0000": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": " ",
    },
    "0000": {
      "value": "5656",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": " ",
    },
    "col3": {
      "value": "5656",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "5656",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  }
];

const columnsDataLabTable = [
  { field: "Chem-7", header: "Chem-7", width: "50px", CustomStyle: { textAlign: "left" }, className: "ThClassLabTableClass FirstCol" },
  { field: "0000", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "ThClassLabTableClass", riskScore: true },
  { field: "col3", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "ThClassLabTableClass", riskScore: true },
  { field: "col4", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "ThClassLabTableClass", riskScore: true },
];


test('Lab Table renders to check column header exists', () => {
  const { container } = render(<CdsTable row={RowDataLabTable}
    columns={columnsDataLabTable}
    type="LabTable"
    width="100%"
    height={"225px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderLabTable}
    customtablestylesbody={customTableStylesBodyLabTable} />);
  const Item = container.getElementsByClassName('ThClassLabTableClass');
  expect(Item.length).toBe(10);
});
it('Lab Table renders to check Class adding to table', () => {
  const { container } = render(<CdsTable row={RowDataLabTable}
    columns={columnsDataLabTable}
    type="LabTable"
    width="100%"
    height={"225px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderLabTable}
    customtablestylesbody={customTableStylesBodyLabTable} />);
  const cdsTableComponent = container.getElementsByClassName('firstClass');
  expect(cdsTableComponent[0]).toHaveClass("firstClass");
});



it('Lab Table renders to Negative Scenario check row counts', () => {
  const { container } = render(<CdsTable row={RowDataLabTable}
    columns={columnsDataLabTable}
    type="LabTable"
    width="100%"
    height={"225px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderLabTable}
    customtablestylesbody={customTableStylesBodyLabTable} />);
  const cdsTableComponent = container.getElementsByTagName('tr');
  expect(cdsTableComponent.length).not.toBeLessThan(5);
});



it('Lab Table renders to check Styles addding dynamically', () => {
  const { container } = render(<CdsTable row={RowDataLabTable}
    columns={columnsDataLabTable}
    type="LabTable"
    width="100%"
    height={"225px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderLabTable}
    customtablestylesbody={customTableStylesBodyLabTable} />);
  const cdsTableComponent = container.getElementsByClassName('FirstCol');
  expect(cdsTableComponent[0]).toHaveStyle({ "width": "50px" });
});

it('Lab Table renders to check negative Styles addding dynamically', () => {
  const { container } = render(<CdsTable row={RowDataLabTable}
    columns={columnsDataLabTable}
    type="LabTable"
    width="100%"
    height={"225px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderLabTable}
    customtablestylesbody={customTableStylesBodyLabTable} />);
  const cdsTableComponent = container.getElementsByClassName('FirstCol');
  expect(cdsTableComponent[0]).not.toHaveStyle({ "width": "20px" });
});

it('Clicking the Negative Scenarios for first Values', () => {
  const { container } = render(<CdsTable row={RowDataLabTable}
    columns={columnsDataLabTable}
    type="LabTable"
    width="100%"
    height={"225px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderLabTable}
    customtablestylesbody={customTableStylesBodyLabTable} />);
  const cdsTableComponent = container.getElementsByClassName('FirstCol');
  expect(cdsTableComponent[0].innerHTML === "Chem-7r").toBeFalsy();
});
////////////////////////////////// LAB TABLE PROPS DATA ENDS ?///////////////////////











////////////////////////////////// Vital Table PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderVitalTable = {
  //  border:"1px solid purple",
}

const customTableStylesBodyVitalTable = {
  // border:"1px solid purple"
}
const RowDataVitalTable = [
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Temperature ",
      "unit": "(F)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "54",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeftVital",
    },

  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Heart Rate ",
      "unit": "(bpm)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "165",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeftVital",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Blood Pressure",
      "unit": "",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "67",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeftVital",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Respiratory rate ",
      "unit": "(counts/min)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "54",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeftVital",
    }
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "SpO2 ",
      "unit": "(%)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": " ",
    },
    "0000": {
      "value": "54",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": " borderLeftVital",
    },
  }
];

const columnsDataVitalTable = [
  { field: "Chem-7", header: "", width: "", CustomStyle: { textAlign: "left" }, className: "VitalTableTh" },
  { field: "0000", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "borderLeft", riskScore: true },
];

test('Vital Table renders to check column header exists', () => {
  const { container } = render(<CdsTable
    row={RowDataVitalTable}
    columns={columnsDataVitalTable}
    type="VitalTable"
    width="100%"
    height={"205px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderVitalTable}
    customtablestylesbody={customTableStylesBodyVitalTable} />);
  const Item = container.getElementsByClassName('VitalTableTh');
  expect(Item.length).toBe(1);
});
it('Vital Table renders to check Class adding to table', () => {
  const { container } = render(<CdsTable
    row={RowDataVitalTable}
    columns={columnsDataVitalTable}
    type="VitalTable"
    width="100%"
    height={"205px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderVitalTable}
    customtablestylesbody={customTableStylesBodyVitalTable} />);
  const cdsTableComponent = container.getElementsByClassName('borderLeftVital');
  expect(cdsTableComponent[0]).toHaveClass("borderLeftVital");
});



it('Vital Table renders to Negative Scenario check row counts', () => {
  const { container } = render(<CdsTable
    row={RowDataVitalTable}
    columns={columnsDataVitalTable}
    type="VitalTable"
    width="100%"
    height={"205px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderVitalTable}
    customtablestylesbody={customTableStylesBodyVitalTable} />);
  const cdsTableComponent = container.getElementsByTagName('tr');
  expect(cdsTableComponent.length).not.toBeLessThan(5);
});



it('Vital Table renders to check Styles addding dynamically', () => {
  const { container } = render(<CdsTable
    row={RowDataVitalTable}
    columns={columnsDataVitalTable}
    type="VitalTable"
    width="100%"
    height={"205px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderVitalTable}
    customtablestylesbody={customTableStylesBodyVitalTable} />);
  const cdsTableComponent = container.getElementsByClassName('VitalTableTh');
  expect(cdsTableComponent[0]).toHaveStyle({ "textAlign": "left" });
});

it('Vital Table renders to check negative Styles addding dynamically', () => {
  const { container } = render(<CdsTable
    row={RowDataVitalTable}
    columns={columnsDataVitalTable}
    type="VitalTable"
    width="100%"
    height={"205px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderVitalTable}
    customtablestylesbody={customTableStylesBodyVitalTable} />);
  const cdsTableComponent = container.getElementsByClassName('VitalTableTh');
  expect(cdsTableComponent[0]).not.toHaveStyle({ "width": "20px" });
});

it('Vital table Clicking the Negative Scenarios for first Values', () => {
  const { container } = render(<CdsTable
    row={RowDataVitalTable}
    columns={columnsDataVitalTable}
    type="VitalTable"
    width="100%"
    height={"205px"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderVitalTable}
    customtablestylesbody={customTableStylesBodyVitalTable} />);
  const cdsTableComponent = container.getElementsByClassName('VitalTableTh');
  expect(cdsTableComponent[0].innerHTML === "Chem-7r").toBeFalsy();
});
////////////////////////////////// VITALS TABLE PROPS DATA ENDS ?///////////////////////










////////////////////////////////// PatientSNapShot TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderPatientSnap = {
  //  border:"1px solid purple",
}

const customTableStylesBodyPatientSnap = {
  // border:"1px solid purple"
}

const RowDataPatientSnap = [
  {
    "id": 1,
    "firstCol": {
      "value": "Cheif Complaint",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShotClass",
    },
    "secondCol": {
      "value": "Recent surgery or procedure",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
  {
    "id": 2,
    "firstCol": {
      "value": "Disposition",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "if so, what surgery or procedure?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
  {
    "id": 3,
    "firstCol": {
      "value": "GCS",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "recent infection?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
  {
    "id": 4,
    "firstCol": {
      "value": "condition(s)",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "known source of infection?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },

  },
  {
    "id": 5,
    "firstCol": {
      "value": "Recent travel?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "",
      "Description": "",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
];

const columnsDataPatientSnap = [
  { field: "firstCol", header: "", width: "50%", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "NoHeader" },
  { field: "secondCol", header: "", width: "50%", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "NoHeader" },
];
test('Patient Snapshot Table renders to check column header exists', () => {
  const { container } = render(<CdsTable
    row={RowDataPatientSnap}
    columns={columnsDataPatientSnap}
    type="PatientSnapShotTable"
    width="100%"
    customtablestylesheader={customTableStylesHeaderPatientSnap}
    customtablestylesbody={customTableStylesBodyPatientSnap} />);
  const Item = container.getElementsByClassName('NoHeader');
  expect(Item.length).toBe(2);
});
it('Patient Snapshot renders to check Class adding to table', () => {
  const { container } = render(<CdsTable
    row={RowDataPatientSnap}
    columns={columnsDataPatientSnap}
    type="PatientSnapShotTable"
    width="100%"
    customtablestylesheader={customTableStylesHeaderPatientSnap}
    customtablestylesbody={customTableStylesBodyPatientSnap} />);
  const cdsTableComponent = container.getElementsByClassName('patientSnapShotClass');
  expect(cdsTableComponent[0]).toHaveClass("patientSnapShotClass");
});



it('Patient Snapshot renders to Negative Scenario check row counts', () => {
  const { container } = render(<CdsTable
    row={RowDataPatientSnap}
    columns={columnsDataPatientSnap}
    type="PatientSnapShotTable"
    width="100%"
    customtablestylesheader={customTableStylesHeaderPatientSnap}
    customtablestylesbody={customTableStylesBodyPatientSnap} />);
  const cdsTableComponent = container.getElementsByTagName('tr');
  expect(cdsTableComponent.length).not.toBeLessThan(3);
});



it('Patient Snapshot renders to check Styles addding dynamically', () => {
  const { container } = render(<CdsTable
    row={RowDataPatientSnap}
    columns={columnsDataPatientSnap}
    type="PatientSnapShotTable"
    width="100%"
    customtablestylesheader={customTableStylesHeaderPatientSnap}
    customtablestylesbody={customTableStylesBodyPatientSnap} />);
  const cdsTableComponent = container.getElementsByClassName('NoHeader');
  expect(cdsTableComponent[0]).toHaveStyle({ "textAlign": "left" });
});

it('Patient Snapshot renders to check negative Styles addding dynamically', () => {
  const { container } = render(<CdsTable
    row={RowDataPatientSnap}
    columns={columnsDataPatientSnap}
    type="PatientSnapShotTable"
    width="100%"
    customtablestylesheader={customTableStylesHeaderPatientSnap}
    customtablestylesbody={customTableStylesBodyPatientSnap} />);
  const cdsTableComponent = container.getElementsByClassName('NoHeader');
  expect(cdsTableComponent[0]).not.toHaveStyle({ "width": "20px" });
});

it('Patient Snapshot Clicking the Negative Scenarios for first Values', () => {
  const { container } = render(<CdsTable
    row={RowDataPatientSnap}
    columns={columnsDataPatientSnap}
    type="PatientSnapShotTable"
    width="100%"
    customtablestylesheader={customTableStylesHeaderPatientSnap}
    customtablestylesbody={customTableStylesBodyPatientSnap} />);
  const cdsTableComponent = container.getElementsByClassName('NoHeader');
  expect(cdsTableComponent[0].innerHTML === "Chem-7r").toBeFalsy();
});
////////////////////////////////// PatientSNapShot TABLE PROPS DATA ENDS ?///////////////////////





////////////////////////////////// RISKSCORE TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderRiskScore = {
  //  border:"1px solid purple",
}

const customTableStylesBodyRiskScore = {
  // border:"1px solid purple"
}

const RowDataRiskScore = [
  {
    "id": 1,
    "rowHide": false,
    "#": {
      "value": "1",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "unit": "",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "unit": "",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 2,
    "#": {
      "value": "2",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 3,
    "#": {
      "value": "3",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 4,
    "#": {
      "value": "4",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "55",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "55%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 5,
    "#": {
      "value": "5",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "RiskColValue",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "8",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "8%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
];

const columnsDataRiskScore = [
  { field: "#", header: "#", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "RiskClass" },
  { field: "RiskFactor", header: "RiskFactor", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "RiskClass" },
  { field: "PatientValue", header: "PatientValue", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "RiskClass" },
  { field: "%", header: "%", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "RiskClass", },
  {
    field: "Contribution", header: "Contribution", width: "100px", CustomStyle: { textAlign: "right", color: "#4B4B4B" }, className: "",
  },
];




test('RiskScore Table Table renders to check column header exists', () => {
  const { container } = render(<CdsTable row={RowDataRiskScore}
    columns={columnsDataRiskScore}
    type="RiskScoreTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderRiskScore}
    customtablestylesbody={customTableStylesBodyRiskScore} />);
  const Item = container.getElementsByClassName('RiskClass');
  expect(Item.length).toBe(4);
});
it('RiskScore Table renders to check Class adding to table', () => {
  const { container } = render(<CdsTable row={RowDataRiskScore}
    columns={columnsDataRiskScore}
    type="RiskScoreTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderRiskScore}
    customtablestylesbody={customTableStylesBodyRiskScore} />);
  const cdsTableComponent = container.getElementsByClassName('RiskColValue');
  expect(cdsTableComponent[0]).toHaveClass("RiskColValue");
});



it('RiskScore Table renders to Negative Scenario check row counts', () => {
  const { container } = render(<CdsTable row={RowDataRiskScore}
    columns={columnsDataRiskScore}
    type="RiskScoreTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderRiskScore}
    customtablestylesbody={customTableStylesBodyRiskScore} />);
  const cdsTableComponent = container.getElementsByTagName('tr');
  expect(cdsTableComponent.length).not.toBeLessThan(3);
});



it('RiskScore Table renders to check Styles addding dynamically', () => {
  const { container } = render(<CdsTable row={RowDataRiskScore}
    columns={columnsDataRiskScore}
    type="RiskScoreTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderRiskScore}
    customtablestylesbody={customTableStylesBodyRiskScore} />);
  const cdsTableComponent = container.getElementsByClassName('RiskClass');
  expect(cdsTableComponent[0]).toHaveStyle({ "textAlign": "left" });
});

it('RiskScore Table renders to check negative Styles addding dynamically', () => {
  const { container } = render(<CdsTable row={RowDataRiskScore}
    columns={columnsDataRiskScore}
    type="RiskScoreTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderRiskScore}
    customtablestylesbody={customTableStylesBodyRiskScore} />);
  const cdsTableComponent = container.getElementsByClassName('RiskClass');
  expect(cdsTableComponent[0]).not.toHaveStyle({ "width": "20px" });
});

it('RiskScore Table Clicking the Negative Scenarios for first Values', () => {
  const { container } = render(<CdsTable row={RowDataRiskScore}
    columns={columnsDataRiskScore}
    type="RiskScoreTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderRiskScore}
    customtablestylesbody={customTableStylesBodyRiskScore} />);
  const cdsTableComponent = container.getElementsByClassName('RiskClass');
  expect(cdsTableComponent[0].innerHTML === "Chem-7r").toBeFalsy();
});
////////////////////////////////// RISKSCORE TABLE PROPS DATA ENDS ?///////////////////////

////////////////////////////////// Info Required TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderInfoRequiredCalculated = {
  //  border:"1px solid purple",
}

const customTableStylesBodyInfoRequiredCalculated = {
  // border:"1px solid purple"
}

const RowDataInfoRequiredCalculated = [
  {
    "id": 1,
    "LabValues": {
      "value": "1st hsTnl",
      "unit": "(ng/L)",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 2,
    "LabValues": {
      "value": "Hct",
      "unit": "(%)",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 3,
    "LabValues": {
      "value": "MCHC",
      "unit": "(g/dL)",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 4,
    "LabValues": {
      "value": "WBC",
      "unit": "(x103/µL)",
      "edited": false,
      "infoRequired": false,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left"
      },
      "className": "Test",
    },
    "value": {
      "value": "55",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 5,
    "LabValues": {
      "value": "BUN",
      "unit": "(mg/dL)",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 6,
    "LabValues": {
      "value": "Cr",
      "unit": "(mg/dL)",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 7,
    "LabValues": {
      "value": "K",
      "unit": "(mmol/L)",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 8,
    "LabValues": {
      "value": "Ca",
      "unit": "(mg/dL)",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "InfoReqClass",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
];

const columnsDataInfoRequiredCalculated = [
  { field: "LabValues", header: "Lab Values", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "NewClsInfoReq" },
  { field: "value", header: "value", width: "", CustomStyle: { textAlign: "right", color: "#4B4B4B" }, className: "InfoReqClass" }
];






test('Info required table Table renders to check column header exists', () => {
  const { container } = render(<CdsTable
    row={RowDataInfoRequiredCalculated}
    columns={columnsDataInfoRequiredCalculated}
    type="InfoRequiredTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderInfoRequiredCalculated}
    customtablestylesbody={customTableStylesBodyInfoRequiredCalculated} />);
  const Item = container.getElementsByClassName('NewClsInfoReq');
  expect(Item.length).toBe(1);
});
it('Info required table renders to check Class adding to table', () => {
  const { container } = render(<CdsTable
    row={RowDataInfoRequiredCalculated}
    columns={columnsDataInfoRequiredCalculated}
    type="InfoRequiredTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderInfoRequiredCalculated}
    customtablestylesbody={customTableStylesBodyInfoRequiredCalculated} />);
  const cdsTableComponent = container.getElementsByClassName('InfoReqClass');
  expect(cdsTableComponent[0]).toHaveClass("InfoReqClass");
});



it('Info required table renders to Negative Scenario check row counts', () => {
  const { container } = render(<CdsTable
    row={RowDataInfoRequiredCalculated}
    columns={columnsDataInfoRequiredCalculated}
    type="InfoRequiredTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderInfoRequiredCalculated}
    customtablestylesbody={customTableStylesBodyInfoRequiredCalculated} />);
  const cdsTableComponent = container.getElementsByTagName('tr');
  expect(cdsTableComponent.length).not.toBeLessThan(3);
});



it('Info required table renders to check Styles addding dynamically', () => {
  const { container } = render(<CdsTable
    row={RowDataInfoRequiredCalculated}
    columns={columnsDataInfoRequiredCalculated}
    type="InfoRequiredTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderInfoRequiredCalculated}
    customtablestylesbody={customTableStylesBodyInfoRequiredCalculated} />);
  const cdsTableComponent = container.getElementsByClassName('NewClsInfoReq');
  expect(cdsTableComponent[0]).toHaveStyle({ "textAlign": "left" });
});

it('Info required table renders to check negative Styles addding dynamically', () => {
  const { container } = render(<CdsTable
    row={RowDataInfoRequiredCalculated}
    columns={columnsDataInfoRequiredCalculated}
    type="InfoRequiredTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderInfoRequiredCalculated}
    customtablestylesbody={customTableStylesBodyInfoRequiredCalculated} />);
  const cdsTableComponent = container.getElementsByClassName('InfoReqClass');
  expect(cdsTableComponent[0]).not.toHaveStyle({ "width": "20px" });
});

it('Info required table Clicking the Negative Scenarios for first Values', () => {
  const { container } = render(<CdsTable
    row={RowDataInfoRequiredCalculated}
    columns={columnsDataInfoRequiredCalculated}
    type="InfoRequiredTable"
    width="100%"
    height={"auto"}
    stickyHeader={true}
    customtablestylesheader={customTableStylesHeaderInfoRequiredCalculated}
    customtablestylesbody={customTableStylesBodyInfoRequiredCalculated} />);
  const cdsTableComponent = container.getElementsByClassName('InfoReqClass');
  expect(cdsTableComponent[0].innerHTML === "Chem-7r").toBeFalsy();
});
////////////////////////////////// Info Required TABLE PROPS DATA ENDS ?///////////////////////

