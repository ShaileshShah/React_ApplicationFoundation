import React from 'react'
import CdsTable from './cdstable'


////////////////////////////////// LAB TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderLabTable = {
  //  border:"1px solid purple",
}

const customTableStylesBodyLabTable = {
  // border:"1px solid purple"
}
const RowDataLabTable = [
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "ssss",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "Test",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "",
    },
    "col3": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "Test",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Na",
      "unit": "(mmol/L)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": " ",
    },
    "0000": {
      "value": "5656",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": " ",
    },
    "col3": {
      "value": "5656",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
    "col4": {
      "value": "5656",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "labTableGreyBg borderLeft",
    },
  }
];

const columnsDataLabTable = [
  { field: "Chem-7", header: "Chem-7", width: "", CustomStyle: { textAlign: "left" }, className: "ThClass" },
  { field: "0000", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "ThClass", riskScore: true },
  { field: "col3", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "ThClass", riskScore: true },
  { field: "col4", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "ThClass", riskScore: true },
];

////////////////////////////////// LAB TABLE PROPS DATA ENDS ?///////////////////////


////////////////////////////////// BAISC TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderBasic = {
  // border:"1px solid purple",
}

const customTableStylesBodyBasic = {
  //  border:"1px solid purple"
}

const RowDataBasic = [
  {
    "id": 1,
    "#": {
      "value": "1",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 2,
    "#": {
      "value": "2",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 3,
    "#": {
      "value": "3",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 4,
    "#": {
      "value": "4",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 5,
    "#": {
      "value": "5",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
];

const columnsDataBasic = [
  { field: "#", header: "#", width: "", CustomStyle: { textAlign: "left" }, className: "" },
  { field: "RiskFactor", header: "RiskFactor", width: "", CustomStyle: { textAlign: "left" }, className: "" },
  { field: "PatientValue", header: "PatientValue", width: "", CustomStyle: { textAlign: "left" }, className: "" },
  { field: "%", header: "%", width: "", CustomStyle: { textAlign: "left" }, className: "ThClass" },
  { field: "Contribution", header: "Contribution", width: "50px", CustomStyle: { textAlign: "right" }, className: "", },
];
////////////////////////////////// BAISC TABLE PROPS DATA ENDS ?///////////////////////


////////////////////////////////// Vital Table PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderVitalTable = {
  //  border:"1px solid purple",
}

const customTableStylesBodyVitalTable = {
  // border:"1px solid purple"
}
const RowDataVitalTable = [
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Temperature ",
      "unit": "(F)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "54",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeft",
    },

  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Heart Rate ",
      "unit": "(bpm)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "165",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Blood Pressure",
      "unit": "",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "67",
      "riskScore": "",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeft",
    },
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "Respiratory rate ",
      "unit": "(counts/min)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "0000": {
      "value": "54",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": "borderLeft",
    }
  },
  {
    "id": 1,
    "rowHide": false,
    "Chem-7": {
      "value": "SpO2 ",
      "unit": "(%)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": " ",
    },
    "0000": {
      "value": "54",
      "riskScore": "high",
      "styles": {
        "textAlign": "right",
      },
      "className": " borderLeft",
    },
  }
];

const columnsDataVitalTable = [
  { field: "Chem-7", header: "", width: "", CustomStyle: { textAlign: "left" }, className: "" },
  { field: "0000", header: "0000", width: "50px", CustomStyle: { textAlign: "right" }, className: "borderLeft", riskScore: true },
];

////////////////////////////////// VITALS TABLE PROPS DATA ENDS ?///////////////////////




////////////////////////////////// RISKSCORE TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderRiskScore = {
  //  border:"1px solid purple",
}

const customTableStylesBodyRiskScore = {
  // border:"1px solid purple"
}

const RowDataRiskScore = [
  {
    "id": 1,
    "rowHide": false,
    "#": {
      "value": "1",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "unit": "",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "unit": "",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "ProgressBar":true,
      "value": "88%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 2,
    "#": {
      "value": "2",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "ProgressBar":true,
      "value": "88%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 3,
    "#": {
      "value": "3",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "88",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "ProgressBar":true,
      "value": "88%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 4,
    "#": {
      "value": "4",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "55",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "ProgressBar":true,
      "value": "55%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
  {
    "id": 5,
    "#": {
      "value": "5",
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "RiskFactor": {
      "value": "Factor Name",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "PatientValue": {
      "value": "0000",
      "unit": "(Unit)",
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "%": {
      "value": "8",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
    "Contribution": {
      "ProgressBar":true,
      "value": "8%",
      "styles": {
        "textAlign": "left",
      },
      "className": "",
    },
  },
];

const columnsDataRiskScore = [
  { field: "#", header: "#", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "" },
  { field: "RiskFactor", header: "RiskFactor", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "" },
  { field: "PatientValue", header: "PatientValue", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "" },
  { field: "%", header: "%", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "", },
  {
    field: "Contribution", header: "Contribution", width: "100px", CustomStyle: { textAlign: "right", color: "#4B4B4B" }, className: "",
  },
];
////////////////////////////////// RISKSCORE TABLE PROPS DATA ENDS ?///////////////////////




////////////////////////////////// PatientSNapShot TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderPatientSnap = {
  //  border:"1px solid purple",
}

const customTableStylesBodyPatientSnap = {
  // border:"1px solid purple"
}

const RowDataPatientSnap = [
  {
    "id": 1,
    "firstCol": {
      "value": "Cheif Complaint",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "Recent surgery or procedure",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
  {
    "id": 2,
    "firstCol": {
      "value": "Disposition",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "if so, what surgery or procedure?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
  {
    "id": 3,
    "firstCol": {
      "value": "GCS",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "recent infection?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
  {
    "id": 4,
    "firstCol": {
      "value": "condition(s)",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "known source of infection?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },

  },
  {
    "id": 5,
    "firstCol": {
      "value": "Recent travel?",
      "Description": "-",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
    "secondCol": {
      "value": "",
      "Description": "",
      "styles": {
        "textAlign": "left",
        "padding": "0px"
      },
      "className": "patientSnapShot",
    },
  },
];

const columnsDataPatientSnap = [
  { field: "firstCol", header: "", width: "50%", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "NoHeader" },
  { field: "secondCol", header: "", width: "50%", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "NoHeader" },
];

////////////////////////////////// PatientSNapShot TABLE PROPS DATA ENDS ?///////////////////////









////////////////////////////////// Info Required TABLE PROPS DATA STARTS ?///////////////////////
const customTableStylesHeaderInfoRequired = {
  //  border:"1px solid purple",
}

const customTableStylesBodyInfoRequired = {
  // border:"1px solid purple"
}

const RowDataInfoRequired = [
  {
    "id": 1,
    "PatientValue": {
      "value": "Age",
      "unit": "",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 2,
    "PatientValue": {
      "value": "Sex",
      "unit": "",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 3,
    "PatientValue": {
      "value": "Race",
      "unit": "",
      "edited": false,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "-",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 4,
    "PatientValue": {
      "value": "Respiratory Rate",
      "unit": "",
      "edited": false,
      "infoRequired": false,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left"
      },
      "className": "Test",
    },
    "value": {
      "value": "45",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
  {
    "id": 5,
    "PatientValue": {
      "value": "Temparature",
      "unit": "",
      "edited": true,
      "infoRequired": true,
      "unitStyles": { "color": "#646464" },
      "styles": {
        "textAlign": "left",
      },
      "className": "Test",
    },
    "value": {
      "value": "55",
      "styles": {
        "textAlign": "right",
        "paddingRight": "10px"
      },
      "className": "",
    }
  },
];

const columnsDataInfoRequired = [
  { field: "PatientValue", header: "Patient Details", width: "", CustomStyle: { textAlign: "left", color: "#4B4B4B" }, className: "" },
  { field: "value", header: "value", width: "", CustomStyle: { textAlign: "right", color: "#4B4B4B" }, className: "" }
];
////////////////////////////////// Info Required TABLE PROPS DATA ENDS ?///////////////////////






const CdsSampleTable = () => {
  return (
    <div style={{ margin: "auto", width: "50%" }}>
      <h2 style={{ textAlign: "left", margin: "0px" }}>Basic Table</h2><hr></hr>
      <CdsTable
        id='cdsBasicTable'
        row={RowDataBasic}
        columns={columnsDataBasic}
        type="BasicTable"
        width="100%"
        height='auto'
        stickyHeader={true}
        customtablestylesheader={customTableStylesHeaderBasic}
        customtablestylesbody={customTableStylesBodyBasic} />
      <br></br>
      <h2 style={{ textAlign: "left", margin: "0px" }}>Lab Table</h2><hr></hr>
      <CdsTable id='cdsLabTable' row={RowDataLabTable}
        columns={columnsDataLabTable}
        type="LabTable"
        width="100%"
        height={"225px"}
        stickyHeader={true}
        customtablestylesheader={customTableStylesHeaderLabTable}
        customtablestylesbody={customTableStylesBodyLabTable} />
      <br></br>
      <h2 style={{ textAlign: "left", margin: "0px" }}>Vitals Table</h2><hr></hr>
      <CdsTable
        id='cdsVitalTable'
        row={RowDataVitalTable}
        columns={columnsDataVitalTable}
        type="VitalTable"
        width="100%"
        height={"205px"}
        stickyHeader={true}
        customtablestylesheader={customTableStylesHeaderVitalTable}
        customtablestylesbody={customTableStylesBodyVitalTable} />
      <br></br>
      <h2 style={{ textAlign: "left", margin: "0px" }}>Patient SnapShot Table</h2><hr></hr>
      <CdsTable
        id='cdsPatienSnapShotTable'
        row={RowDataPatientSnap}
        columns={columnsDataPatientSnap}
        type="PatientSnapShotTable"
        width="100%"
        customtablestylesheader={customTableStylesHeaderPatientSnap}
        customtablestylesbody={customTableStylesBodyPatientSnap} />
      <br></br>
      <h2 style={{ textAlign: "left", margin: "0px" }}>RiskScore Table</h2><hr></hr>
      <CdsTable id='cdsRiskScoreTable' row={RowDataRiskScore}
        columns={columnsDataRiskScore}
        type="RiskScoreTable"
        width="100%"
        height={"auto"}
        stickyHeader={true}
        customtablestylesheader={customTableStylesHeaderRiskScore}
        customtablestylesbody={customTableStylesBodyRiskScore} />
      <br></br>
      <h2 style={{ textAlign: "left", margin: "0px" }}>Info required Table</h2><hr></hr>
      <CdsTable
        id='cdsInfoRequiredTable'
        row={RowDataInfoRequired}
        columns={columnsDataInfoRequired}
        type="InfoRequiredTable"
        width="100%"
        height={"auto"}
        stickyHeader={true}
        customtablestylesheader={customTableStylesHeaderInfoRequired}
        customtablestylesbody={customTableStylesBodyInfoRequired} />
      <br></br>
    </div>
  )
}

export default CdsSampleTable
