import * as React from 'react';
import { styled } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
// import TableCell, { tableCellClasses } from '@material-ui/core/TableCell';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import {GridRowsProp} from '@mui/x-data-grid';
import "./cdstable.css"
import { TABLE } from '../utilities/constants';
import { TABLETYPES } from '../utilities/constants';
import { GetIcons } from '../utilities/GetIcons';
import CDSButton from '../cdsbutton/cdsbutton';

const tableCellClasses = {
  head: "",
  body: "",
};

type ColumnDataType = {
  id?:string
  row?: GridRowsProp
  columns?: GridRowsProp
  type?: string
  width?: string
  height?: string
  stickyHeader?: boolean
  customtablestylesheader?: {}
  customtablestylesbody?: {}
}


const CdsTable = ({id,row, columns, type, width, height, stickyHeader, customtablestylesheader, customtablestylesbody }: ColumnDataType) => {

  const StyledTableCell = styled(TableCell)(({ }) => ({
    padding: '8px',
    [`&.${tableCellClasses.head}`]: customtablestylesheader !== undefined && Object.keys(customtablestylesheader).length !== 0 ? customtablestylesheader : {
      backgroundColor: type === TABLETYPES.LabTable || type === TABLETYPES.VitalTable ? TABLE.BackgroundColor : TABLE.BackgroundColor,
      color: TABLE.color,
      padding: TABLE.padding,
      fontFamily: TABLE.font,
      fontSize: TABLE.fontSize
    },
    [`&.${tableCellClasses.body}`]: customtablestylesbody !== undefined && Object.keys(customtablestylesbody).length !== 0 ? customtablestylesbody : {
      fontSize: TABLE.fontSize,
      padding: TABLE.tableBodyPadding,
    },
    '&.b-0': {
      border: 0
    }
  }));

  const StyledTableRow = styled(TableRow)(({ }) => ({
    'td': {
      padding: TABLE.tableBodyPadding,
    },
  }));


  return (
    <TableContainer style={{ width: `${width}!important`, maxHeight: `${height}!important`, minHeight: `${height}!important`, height: `${height}!important`, }} component={Paper}>
      <Table id = {id} stickyHeader={stickyHeader} style={{ width: `100%!important` }} aria-label="customized table">
        <TableHead>
          <TableRow>
            {columns?.map((x) => {
              if (x.riskScore?.length !== 0 && x.riskScore !== undefined && x.riskScore !== null) {
                return <StyledTableCell key={Math.random()} className={x.className + " b-0"} style={{ width: x.width }}>
                  <Table className='TableInner'>
                    <TableBody>
                      <StyledTableRow key={Math.random()}>
                        <StyledTableCell key={Math.random()} className={x.className} style={{ width: x.width, border: 0, ...x.CustomStyle }} align={x.Align}>{x.header}</StyledTableCell>
                        <StyledTableCell key={Math.random()} className={x.className} style={{ width: x.width, border: 0, ...x.CustomStyle }} align={x.Align}>{GetIcons("ErrorSharpIcon", TABLE.ErrorIconStyleHidden)}</StyledTableCell>
                      </StyledTableRow>
                    </TableBody>
                  </Table>
                </StyledTableCell>
              } else {
                return <StyledTableCell key={Math.random()} className={x.className} style={{ width: x.width, ...x.CustomStyle }} align={x.Align}>{x.header}</StyledTableCell>
              }
            })}
          </TableRow>
        </TableHead>
        <TableBody>
          {row?.map((Item) => (
            <StyledTableRow key={Math.random()} style={{ display: Item.rowHide ? "none" : "table-row" }}>
              {type === TABLETYPES.LabTable || type === TABLETYPES.VitalTable ?
                columns?.map((x) => {
                  if (Item[x.field]?.riskScore !== undefined && Item[x.field]?.riskScore.length !== 0 && Item[x.field]?.riskScore !== null) {
                    return <StyledTableCell key={Math.random()} className={Item[x.field]?.className}>
                      <Table className='TableInner'>
                        <TableBody>
                          <StyledTableRow key={Math.random()}>
                            <StyledTableCell style={Item[x.field]?.styles} className={`${Item[x.field]?.className+ " b-0"} riskHigh`}>{Item[x.field]?.value}</StyledTableCell>
                            <StyledTableCell style={Item[x.field]?.styles} className={Item[x.field]?.className + " b-0"}>{GetIcons("ErrorSharpIcon", TABLE.ErrorIconStyle)}</StyledTableCell>
                          </StyledTableRow>
                        </TableBody>
                      </Table>
                    </StyledTableCell>
                  } else {
                    return <StyledTableCell key={Math.random()} className={Item[x.field]?.className}>
                      <Table className='TableInner'>
                        <TableBody>
                          <StyledTableRow key={Math.random()}>
                            <StyledTableCell style={Item[x.field]?.styles} className={Item[x.field]?.className+ ' b-0'}>{Item[x.field]?.value} <span style={Item[x.field]?.unitStyles}>{Item[x.field]?.unit}</span> </StyledTableCell>
                            <StyledTableCell style={Item[x.field]?.styles} className={Item[x.field]?.className + ' b-0'}>{GetIcons("ErrorSharpIcon", TABLE.ErrorIconStyleHidden)}</StyledTableCell>
                          </StyledTableRow>
                        </TableBody>
                      </Table>
                    </StyledTableCell>
                  }
                })
                : type === TABLETYPES.PatientSnapShotTable ?
                  columns?.map((x) => {
                    return <StyledTableCell key={Math.random()} className={`${Item[x.field]?.className} patientSnapShot`}>
                      <Table className='TableInner'>
                        <TableBody>
                          <StyledTableRow key={Math.random()}>
                            <StyledTableCell 
                            style={Item[x.field]?.styles} className={`${Item[x.field]?.className} b-0`}>{Item[x.field]?.value}</StyledTableCell>
                          </StyledTableRow>
                          <StyledTableRow key={Math.random()}>
                            <StyledTableCell 
                            style={Item[x.field]?.styles} className={`${Item[x.field]?.className} b-0`}>{Item[x.field]?.Description}</StyledTableCell>
                          </StyledTableRow>
                        </TableBody>
                      </Table>
                    </StyledTableCell>
                  })
                  : type === TABLETYPES.RiskScoreTable ?
                    columns?.map((x) => {
                      return <StyledTableCell key={Math.random()} className={`${Item[x.field]?.className} RiskScoreTable`}>
                        <Table className='TableInner'>
                          <TableBody>
                            <StyledTableRow key={Math.random()}>
                              {Item[x.field]?.ProgressBar ?
                                  <CDSButton
                                    buttonText={Item[x.field]?.value}
                                    textColor={'red'}
                                    btnColor={'white'}
                                    toolTip={'Button Tooltip'}
                                    variant={'outlined'}
                                    disabled={false}
                                    startIcon={false}
                                    endIcon={false}
                                    iconButton={false}
                                    onClickevent={() => { }}
                                    width={'100%'}
                                    justifyContent={'Left'}
                                    customClassName={"tblClass"}
                                  />
                                :
                                <StyledTableCell style={Item[x.field]?.styles} className={Item[x.field]?.className + ' b-0'}>{Item[x.field]?.value} <span style={Item[x.field]?.unitStyles}>{Item[x.field]?.unit}</span> </StyledTableCell>
                              }
                            </StyledTableRow>
                          </TableBody>
                        </Table>
                      </StyledTableCell>
                    })
                    : type === TABLETYPES.InfoRequiredTable ?
                      columns?.map((x) => {
                        if (Item[x.field]?.edited !== undefined && Item[x.field]?.edited.length !== 0 && Item[x.field]?.edited !== null && !Item[x.field]?.edited && Item[x.field]?.infoRequired) {
                          return <StyledTableCell key={Math.random()} className={`${Item[x.field]?.className} InfoRequiredTable`}>
                            <Table className='TableInner'>
                              <TableBody>
                                <StyledTableRow key={Math.random()}>
                                  <StyledTableCell  style={{...Item[x.field]?.styles, border: 0, width: "5%" }} className={Item[x.field]?.className}>{GetIcons("HelpIcon", TABLE.WariningIconStyle)}</StyledTableCell>
                                  <StyledTableCell style={{ ...Item[x.field]?.styles, border: 0, width: "95%"}} className={Item[x.field]?.className}>{Item[x.field]?.value} <span style={Item[x.field]?.unitStyles}>{Item[x.field]?.unit}</span> </StyledTableCell>
                                </StyledTableRow>
                              </TableBody>
                            </Table>
                          </StyledTableCell>
                        } else if (Item[x.field]?.edited !== undefined && Item[x.field]?.edited.length !== 0 && Item[x.field]?.edited !== null && Item[x.field]?.edited && Item[x.field]?.infoRequired) {
                          return <StyledTableCell key={Math.random()} className={`${Item[x.field]?.className} InfoRequiredTable`}>
                            <Table className='TableInner'>
                              <TableBody>
                                <StyledTableRow key={Math.random()}>
                                  <StyledTableCell style={{...Item[x.field]?.styles, border: 0, width: "5%" }} className={Item[x.field]?.className}>{GetIcons("DoneIcon", TABLE.DoneIconStyle)}</StyledTableCell>
                                  <StyledTableCell style={{...Item[x.field]?.styles, border: 0, width: "95%"}} className={Item[x.field]?.className}>{Item[x.field]?.value} <span style={Item[x.field]?.unitStyles}>{Item[x.field]?.unit}</span> </StyledTableCell>
                                </StyledTableRow>
                              </TableBody>
                            </Table>
                          </StyledTableCell>
                        } else {
                          return <StyledTableCell key={Math.random()} className={`${Item[x.field]?.className} InfoRequiredTable`}>
                            <Table className='TableInner'>
                              <TableBody>
                                <StyledTableRow key={Math.random()}>
                                  <StyledTableCell style={{border: 0, width: "5%" , ...Item[x.field]?.styles}} className={Item[x.field]?.className}>{GetIcons("HelpIcon", TABLE.WariningIconStyleHidden)}</StyledTableCell>
                                  <StyledTableCell style={{border: 0, width: "5%" , ...Item[x.field]?.styles}} className={Item[x.field]?.className}>{Item[x.field]?.value} <span style={Item[x.field]?.unitStyles}>{Item[x.field]?.unit}</span> </StyledTableCell>
                                </StyledTableRow>
                              </TableBody>
                            </Table>
                          </StyledTableCell>
                        }
                      })
                      :
                      columns?.map((x) => {
                        return <StyledTableCell key={Math.random()} style={Item[x.field]?.styles} className={Item[x.field]?.className}>{Item[x.field]?.value}</StyledTableCell>
                      })}
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
export default CdsTable
