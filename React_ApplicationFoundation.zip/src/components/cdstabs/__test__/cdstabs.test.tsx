import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import CDStabs from '../../cdstabs/cdstabs';
import CDSAplHeader from '../../cdsAppHeader/cdsappheader';

const tabsLay = [
    { label: 'Tab 1', disabled: false },
    { label: 'tab 2', disabled: true }];
const tabsLay2 = [
    { label: 'Tab 1', disabled: false },
    { label: 'tab 2', disabled: false }];

const tabsLay3 = [
    { label: 'Tab 1', disabled: true },
    { label: 'tab 2', disabled: false }];

const tabsNav2 = [
    <CDSAplHeader
        title={'Risk Details'}
        subtitle={'Subheading'}
        desc={'(Heading Desc)'}
        headerStyles={'Headline 1 Bold'}
        subtitleStyles={'Subtitle 1 Bold'}
        background={'#e0e0e0'}
        customStyleHeader={{}}
        customStylesubHeader={{ fontSize: 12 }}
        customStyleHeaderDesc={{}}
        customImageSrc={' '}
    />,

]

test('renders first tab', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={1} tabsLabel={tabsLay2} tabsNavigation={tabsNav2} />);
    const tabElement = screen.getByText(/Tab 1/i);
    expect(tabElement).toBeInTheDocument();
});
test('renders second tab', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={2} tabsLabel={tabsLay2} tabsNavigation={tabsNav2} />);
    const tabElement = screen.getByText(/Tab 2/i);
    expect(tabElement).toBeInTheDocument();
});
test('renders default as first tab component', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={1} tabsLabel={tabsLay2} tabsNavigation={tabsNav2} />);
    const tabElement = screen.getByText(/Tab 1/i);
    expect(tabElement).toBeInTheDocument();
});
test('renders default as second tab component', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={2} tabsLabel={tabsLay2} tabsNavigation={tabsNav2} />);
    const tabElement = screen.getByText(/Tab 1/i);
    const tabElement2 = screen.getByRole('tab', { name: 'tab 2' });
    fireEvent.click(tabElement2);
    expect(tabElement).toBeInTheDocument();
    expect(screen.getByRole('tab', { selected: true })).toHaveTextContent('tab 2');
});
test('renders first tab on click event', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={1} tabsLabel={tabsLay2} tabsNavigation={tabsNav2} />);
    const tab1Element = screen.getByRole('tab', { name: 'Tab 1' });
    fireEvent.click(tab1Element);
    expect(screen.getByRole('tab', { selected: true })).toHaveTextContent('Tab 1');
});

test('renders second tab as disabled', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={2} tabsLabel={tabsLay} tabsNavigation={tabsNav2} />);
    const tab2Element = screen.getByText(/tab 2/i).closest("button");;
    expect(tab2Element?.className.split(' ').includes("Mui-selected")).toBe(true);
});
test('renders first tab as not disabled', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={1} tabsLabel={tabsLay} tabsNavigation={tabsNav2} />);
    const tab2Element = screen.getByText(/Tab 1/i).closest("button");
    //.props.className.split(' ').includes('welcome-framework')).toBe(true)
    //expect(tab2Element?.className.split(' ').includes("Mui-selected")).toBe(true);
    expect(tab2Element?.getAttribute("tabindex")).toBe("0");
});
test('renders first tab as disabled', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={2} tabsLabel={tabsLay3} tabsNavigation={tabsNav2} />);
    const tab1Element = screen.getByText(/Tab 1/i).closest("button");
    expect(tab1Element).not.toHaveClass("Mui-selected");
});
test('renders second tab as not disabled', () => {
    render(<CDStabs totalTab={2} defaulTabIndex={2} tabsLabel={tabsLay3} tabsNavigation={tabsNav2} />);
    const tab1Element = screen.getByText(/tab 2/i).closest("button");
    console.log("tab1Element", tab1Element);
    expect(tab1Element).toHaveClass("Mui-selected");
});