import React, { FunctionComponent } from 'react';
import { useState } from 'react';
import { Tab, Box } from '@material-ui/core';
import styled from 'styled-components';
import { TabContext, TabPanel, TabList } from '@material-ui/lab';
import { TABS, TABLIST, TABPANEL } from '../utilities/constants';

interface Tabparmeter {
    label: string;
    disabled: boolean;
}
export interface CDSTabsProps {
    id?:string
    totalTab: number
    tabsLabel: Tabparmeter[]
    tabsNavigation: Array<any>
    defaulTabIndex: number
    customStyleTab?: {}
    customStyleTabList?: {}
    customStyleTabPanel?: {}
}

const CustomTabList = styled(TabList)`
text-transform:${(TABLIST.textTransform)};    
.MuiTabs-indicator{ background-color:${(TABLIST.indicator.backgroundColor)};
color:${(TABLIST.indicator.color)};
};
& .MuiTab-root { 
background-color:${(TABLIST.root.backgroundColor)};
color:${(TABLIST.root.color)};
border-top: ${(TABLIST.borderTop)}; 
border-right:${(TABLIST.borderRight)};
border-left: ${(TABLIST.borderLeft)};
};
& .Mui-selected {background-color:${(TABLIST.tabSelected.backgroundColor)};
color: ${(TABLIST.tabSelected.color)};
font-weight:${(TABLIST.tabSelected.fontweight)}};
text-transform:${(TABLIST.textTransform)};                
`;
// ${(TABLIST.tabSelected.color)};
const CDStabsSection = styled(Tab)`
border-radius: ${(TABS.borderRadius)};
color: ${(TABS.fontcolor)};
text-transform: ${(TABS.textTransform)}; 
&.Mui-selected'{
    color:${TABLIST.tabSelected.color}
}
:hover{
    color:${(TABS.hover.fontcolor)}  
}`;

const CustomTabPanel = styled(TabPanel)`
text-transform:${(TABPANEL.textTransform)};
`;

const CDSTabs: FunctionComponent<CDSTabsProps> = (props: CDSTabsProps) => {
    const [tabValue, setTabValue] = useState(props.tabsLabel[props.defaulTabIndex - 1].label.toString());
    const handleTabs = (e: any, value: string) => {
        console.log(e);
        setTabValue(value);
    };
    return (
        <TabContext value={tabValue}>
            {props.tabsLabel!==null && props.tabsLabel.length > 0 && props.tabsLabel.length===props.totalTab ?
                <CustomTabList style={props.customStyleTabList} onChange={handleTabs}>
                    {props.tabsLabel.map((tabname) =>
                        <CDStabsSection 
                        style={props.customStyleTab} 
                        value={tabname.label} label={tabname.label} disabled={tabname.disabled} 
                        />
                    )}
                </CustomTabList> 
                : <></>}
            <Box>
                {props.tabsNavigation!==null &&props.tabsNavigation.length > 0 && props.tabsNavigation.length===props.totalTab ?
                    props.tabsNavigation.map((tabsNav, index) =>
                        <CustomTabPanel 
                        style={props.customStyleTabPanel} 
                        value={props.tabsLabel[index].label.toString()}>
                            {tabsNav}
                        </CustomTabPanel>) 
                        : <></>}


            </Box>

        </TabContext>

    )
}
export default CDSTabs;
