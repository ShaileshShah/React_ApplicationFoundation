import React from 'react';
import CDStabs from './cdstabs';
import { Box } from '@material-ui/core';
import CDSAplHeader from '../cdsAppHeader/cdsappheader';
//import CdsSampleStoryBook from '../cdssamplestoryBook/index'
import CdsSampleTable from '../cdstable/cdssampletable'


const CDSTabsLayout = () => {
    const tabs = [
        { label: 'Risk Details', disabled: false },
        { label: 'Patient Details', disabled: false },
        { label: 'Vital Details', disabled: true }];
    const tabsNav = [
        <CDSAplHeader
            id={'cdsAplHeader'}
            title={'Risk Details'}
            subtitle={'Subheading'}
            desc={'(Heading Desc)'}
            headerStyles={'Headline 1 Bold'}
            subtitleStyles={'Subtitle 1 Bold'}
            background={'#e0e0e0'}
            customStyleHeader={{}}
            customStylesubHeader={{ fontSize: 12 }}
            customStyleHeaderDesc={{}}
            customImageSrc={' '}
        />,
        <CdsSampleTable />,
        <CDSAplHeader
            title={'Vitals Details'}
            subtitle={'Subheading'}
            desc={'(Heading Desc)'}
            headerStyles={'Headline 1 Regular'}
            subtitleStyles={'Subtitle 1 Italics'}
            background={'#e0e0e0'}
            customStyleHeader={{}}
            customStylesubHeader={{ fontSize: 12 }}
            customStyleHeaderDesc={{}}
            customImageSrc={' '}
        />
    ]

    const tabsLay2 = [
        { label: 'Tab 1', disabled: false },
        { label: 'tab 2', disabled: false }];

    //const tabsLay3 = new Array<Tabparmeter>;


    const tabsNav2 = [
        <CDSAplHeader
            title={'Risk Details'}
            subtitle={'Subheading'}
            desc={'(Heading Desc)'}
            headerStyles={'Headline 1 Bold'}
            subtitleStyles={'Subtitle 1 Bold'}
            background={'#e0e0e0'}
            customStyleHeader={{}}
            customStylesubHeader={{ fontSize: 12 }}
            customStyleHeaderDesc={{}}
            customImageSrc={' '}
        />,
        // <CdsSampleStoryBook />,

    ]

    return (<ul>
        <li>{'3 Tabs layout'}</li>
        <Box 
        style={{ marginTop: 5 }}
        >
            <CDStabs totalTab={3} defaulTabIndex={2} tabsLabel={tabs} tabsNavigation={tabsNav} />
        </Box>
        <li>{'2 Tabs layout'}</li>
        <Box 
        style={{ marginTop: 5 }}
        >
            <CDStabs totalTab={2} defaulTabIndex={1} tabsLabel={tabsLay2} tabsNavigation={tabsNav2} />
        </Box></ul>

    )
}
export default CDSTabsLayout;