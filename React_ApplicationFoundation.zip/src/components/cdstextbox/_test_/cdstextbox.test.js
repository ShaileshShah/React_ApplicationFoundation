import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Cdstextbox from '../cdstextbox.tsx'

const field = {
  key: "appName",
  label: "Application Name",
  placeholder: "Application Name",
  inputType: "text",
  inputDatatype: "string",
  helperText: "enter Application name",
  defaultValue: "defaultValue",
  value: "Test",
  required: true,
  disabled: false,
  styleLabel: {
    background: "white!important",
    color: "red!important",
    fontSize: "14px!important"
  },
  styleInput: {
    width: "100%!important",
    color: "purple!important",
  },
  styleError: {
    color: "blue!important",
  },
};


const validation = {
  required: true,
  requiredErrorMsg: "",
  minLength: 6,
  minLengthErrorMsg: "min custom error",
  maxLength: 10,
  maxLengthErrorMsg: "",
  isNumeric: false,
  specialCharacterCheck: true,
  regex: "^[A-Za-z]{0,}[a-zA-Z0-9]{0,}$",
  regexErrorMsg: "",
};




describe('TextBox', () => {
  it('Renders TextBox Check placeholder', () => {
    const handleChange = jest.fn();
    render(
      <Cdstextbox fields={field} required={true} validation={validation} />
    );
    const cdstextboxComponent = screen.getAllByPlaceholderText('Application Name');
    expect(cdstextboxComponent[0].placeholder).toBe('Application Name');
  });

  it('Renders TextBox Check required', () => {
    const handleChange = jest.fn();
    render(
      <Cdstextbox fields={field} required={true} validation={validation} />
    );
    const cdstextboxComponent = screen.getAllByPlaceholderText('Application Name');
    expect(cdstextboxComponent[0].required).toBe(true);
  });

  it('Renders TextBox Check Disabled', () => {
    const handleChange = jest.fn();
    render(
      <Cdstextbox fields={field} required={true} validation={validation} />
    );
    const cdstextboxComponent = screen.getAllByPlaceholderText('Application Name');
    expect(cdstextboxComponent[0].disabled).toBe(false);
  });

  it('Renders TextBox Check Default Value', () => {
    const handleChange = jest.fn();
    render(
      <Cdstextbox fields={field} required={true} validation={validation} />
    );
    const cdstextboxComponent = screen.getAllByPlaceholderText('Application Name');
    expect(cdstextboxComponent[0].defaultValue).toBe("defaultValue");
  });

  it('Renders TextBox Check Input Type', () => {
    render(
      <Cdstextbox fields={field} required={true} validation={validation} />
    );
    const cdstextboxComponent = screen.getAllByPlaceholderText('Application Name');
    expect(cdstextboxComponent[0].type).toBe("text");
  });



  it('Renders TextBox Check onChange', () => {  
    const onChange = jest.fn();
    render(<Cdstextbox className="errorWarning" fields={field} required={true} validation={validation} HandleChangeFunc={onChange} />);
    const input = screen.getAllByPlaceholderText('Application Name');
    userEvent.type(input[0], 'test');   
    expect(onChange).toHaveBeenCalled();
  });

});
