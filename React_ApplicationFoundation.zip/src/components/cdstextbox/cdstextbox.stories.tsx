import React from 'react'
import { ComponentStory, ComponentMeta } from '@storybook/react'
import TextBox from './cdstextbox'

export default {
    title: 'CDS TextBox',
    component: TextBox,
    argTypes: {
        disabled: { type: 'boolean' },
        CustomStyles: { type: 'boolean' },
        HandleChangeFunc: { action: "onchange" }
    },
} as unknown as ComponentMeta<typeof TextBox>

const Template: ComponentStory<typeof TextBox> = (args) => (
    <TextBox {...args} />
)

export const textbox = Template.bind({})
textbox.args = {
    fields: {
        // label: "Application Name",
        placeholder: "Application Name",
        inputType: "text",
        inputDatatype: "string",
        defaultValue: "",
    },
    validation: {
        required: true,
        requiredErrorMsg: "",
        minLength: 2,
        minLengthErrorMsg: "",
        maxLength: 8,
        maxLengthErrorMsg: "",        
        isNumeric: false,
        isNumericErrorMsg: "it should be nuemeirc",
        regex: "^[A-Za-z]{0,}[a-zA-Z0-9]{0,}$",
        regexErrorMsg: "",
    },
    width:"100%",
    customClassInput:"customClassName",
    customIdInput:"customIdInput",
    WarningStyle: {
        borderColor: "",
        FontColor:"",
        iconTextColor:"",
        fontWeight:500,
    },    
    ErrorStyle: {
        borderColor: "",
        FontColor:"",
        iconTextColor:"",
        fontWeight:500,
    },
    
    NormalStyle: {
        borderColor: "",
        FontColor:"",
        iconTextColor:"",
        fontWeight:500,
    },

    // LabelStyle: {
    //     FontColor:"",
    //     fontWeight:500,
    // }
    
}

