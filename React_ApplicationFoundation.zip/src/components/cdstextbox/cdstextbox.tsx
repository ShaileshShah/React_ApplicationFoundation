import React, { useState } from 'react';
import { TextField, Typography } from '@material-ui/core';
import "./cdstextbox.css"
import handleValidation from '../utilities/Validator';
import styled from '@emotion/styled';


let changeStatus = false
let changevarient = { isValid: true, message: "" }
type InputFieldProps = {

    customClassLabel?: string,
    customClassInput?: string,
    customClassError?: string,
    customIdInput?: string,
    fields: {
        styleInput?: {}
        styleLabel?: {}
        styleError?: {}
        key?: string
        size?: string
        label?: string
        placeholder?: string
        inputType?: string
        inputDatatype?: string
        helperText?: string
        defaultValue?: string
        value?: string
        required?: boolean
        error?: boolean
        disabled?: boolean
        validation?: {
            specialCharacterCheck?: boolean
            required?: boolean
            minLength?: number
            maxLength?: number
            isNumeric?: boolean
            error?: string
            regex?: string
        }
    }
    textConfig?: {
        value: string
    }
    varientCheck?: "filled" | "warning" | "error"
    required?: boolean
    width?: string
    disabled?: boolean
    HandleChangeFunc?: Function
    validation?: any
    CustomStyles?: boolean
    WarningStyle?: {
        background?: String,
        borderColor?: String,
        FontColor?: String,
        iconTextColor?: String,
        fontWeight?: number,
    }
    ErrorStyle?: {
        background?: String,
        borderColor?: String,
        FontColor?: String,
        iconTextColor?: String,
        fontWeight?: number,
    }
    NormalStyle?: {
        background?: String,
        borderColor?: String,
        FontColor?: String,
        iconTextColor?: String,
        fontWeight?: number,
    }
    LabelStyle?: {
        FontColor?: String,
        fontWeight?: number,
    }
    onChange?: React.ChangeEventHandler<HTMLTextAreaElement | HTMLInputElement> | (React.ChangeEventHandler<HTMLTextAreaElement | HTMLInputElement> & void) | undefined
}


type ErrorObj = {
    isValid: boolean, message: string
}

let CurrentState = {
    value: ""
}



const StyledTextField = styled(TextField)`
        width: 100%;  
        & label.Mui-focused {
        color: white;
        }
        & .MuiInput-underline:after {
        border-bottom-color: white;
        }
        & .MuiOutlinedInput-root {
        & fieldset {
            border: ${(props: InputFieldProps) => props.CustomStyles ? CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? `1px solid ${props.WarningStyle?.borderColor}!important` : `1px solid ${props.NormalStyle?.borderColor}!important` : !changevarient.isValid && !props.disabled ? `1px solid ${props.ErrorStyle?.borderColor}!important` : `1px solid ${props.NormalStyle?.borderColor}!important` : CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? "1px solid #ffca2c!important" : "1px solid #ddd!important" : !changevarient.isValid && !props.disabled ? "1px solid red!important" : "1px solid #ddd!important"}
        }& input {
            color: ${(props: InputFieldProps) => props.CustomStyles ? CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? `${props.WarningStyle?.FontColor}!important` : ` ${props.NormalStyle?.FontColor }!important` : !changevarient.isValid && !props.disabled ? `${props.ErrorStyle?.FontColor }!important` : `${props.NormalStyle?.FontColor }!important` : ""};
            font-weight: ${(props: InputFieldProps) => props.CustomStyles ? CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? `${props.WarningStyle?.fontWeight }!important` : ` ${props.NormalStyle?.fontWeight  }!important` : !changevarient.isValid && !props.disabled ? `${props.ErrorStyle?.fontWeight  }!important` : `${props.NormalStyle?.fontWeight  }!important` : ""}
        }
        &:hover fieldset {
            border: ${(props: InputFieldProps) => props.CustomStyles ? CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? `2px solid ${props.WarningStyle?.borderColor}!important` : `2px solid ${props.NormalStyle?.borderColor}!important` : !changevarient.isValid && !props.disabled ? `2px solid ${props.ErrorStyle?.borderColor}!important` : `2px solid ${props.NormalStyle?.borderColor}!important` : CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? "2px solid #ffca2c!important" : "2px solid #ddd!important" : !changevarient.isValid && !props.disabled ? "2px solid red!important" : "1px solid #ddd!important"}
        }
        &.Mui-focused fieldset {
            border: ${(props: InputFieldProps) => props.CustomStyles ? CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? `3px solid ${props.WarningStyle?.borderColor}!important` : `3px solid ${props.NormalStyle?.borderColor}!important` : !changevarient.isValid && !props.disabled ? `3px solid ${props.ErrorStyle?.borderColor}!important` : `3px solid ${props.NormalStyle?.borderColor}!important` : CurrentState?.value?.trim().length === 0 ? CurrentState?.value?.trim().length === 0 && changeStatus && props.validation.required && !props.disabled ? "3px solid #ffca2c!important" : "3px solid #ddd!important" : !changevarient.isValid && !props.disabled ? "3px solid red!important" : "1px solid #ddd!important"}
        }
        }
        `;



const TextBox = (props: InputFieldProps) => {
    const [error, setError] = useState<ErrorObj>({ isValid: true, message: "enter the name" });
    const [errorWarning, seterrorWarning] = useState("");
    let tempErrors = { isValid: false, message: "enter the name" }


    const handleChange = (event: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => {
        const { value } = event.target;
        changeStatus = true
        CurrentState = {
            value: value
        }
        const validationError = handleValidation(props.validation, CurrentState);

        Object.assign(tempErrors, validationError);
        tempErrors = validationError;
        changevarient = validationError;
        setError(tempErrors)
        if (value.length == 0 && changeStatus) {
            value.length == 0 && changeStatus ? setError(validationError) : setError({ isValid: true, message: validationError.message })
            value.length == 0 && changeStatus ? seterrorWarning("errorWarning") : seterrorWarning("default")
        } else if (!validationError.isValid) {
            !validationError.isValid && changeStatus ? seterrorWarning("errorError") : seterrorWarning("default")
            !validationError.isValid && changeStatus ? setError(validationError) : setError({ isValid: true, message: validationError.message })
        }
        props.HandleChangeFunc && props.HandleChangeFunc(event)
        // setError(validateInput(props.fields.validation, value));        

    };
    let statusErrorCheck = 1;
    let varientCheck;
    if (!props.CustomStyles) {
        varientCheck = CurrentState?.value?.trim().length == 0 && changeStatus && props.validation.required && !props.disabled ? {
            startAdornment: <span className='IconTextBox' style={{ background: "#ffca2c", fontWeight: "700", padding: "0px 7px 0px 7px", borderRadius: "50%" }}>?</span>,
            className: props.customClassInput
        } : !error.isValid && CurrentState?.value?.trim().length !== 0 && !props.disabled ? {
            startAdornment: <span className='IconTextBox' style={{ background: "red", fontWeight: "700", padding: "0px 9px 0px 9px", color: "#fff", borderRadius: "50%" }}>!</span>, className: props.customClassInput
        } : { className: props.customClassInput }
    } else {
        varientCheck = CurrentState?.value?.trim().length == 0 && changeStatus && props.validation.required && !props.disabled ? {            
            startAdornment: <span className='IconTextBox' style={{ background: props.WarningStyle?.borderColor?.toString(), fontWeight: "700", color: props.WarningStyle?.iconTextColor?.toString(), padding: "0px 7px 0px 7px", borderRadius: "50%" }}>?<span style={{display:"none"}}>{statusErrorCheck = 2}</span></span>,
            className: props.customClassInput
        } : !error.isValid && CurrentState?.value?.trim().length !== 0 && !props.disabled ? {
            startAdornment: <span className='IconTextBox' style={{ background: props.ErrorStyle?.borderColor?.toString(), fontWeight: "700", padding: "0px 9px 0px 9px", color: props.ErrorStyle?.iconTextColor?.toString(), borderRadius: "50%" }}>!<span style={{display:"none"}}>{statusErrorCheck = 3}</span></span>, className: props.customClassInput
        } : { className: props.customClassInput, startAdornment:<span style={{display:"none"}}>{statusErrorCheck=1}</span>}
    }



    return (
        <div className="form-group" style={{ width: `${props.width}` }}>
            {/* <Typography className={`labelTextField }`} sx={{ color: props?.disabled ? "#a9a9a9" : "#000", padding: "5px",}}>
                {props.CustomStyles && <span style={{color: props.LabelStyle?.FontColor?.toString(), fontWeight: props.LabelStyle?.fontWeight?.toString()}}>{props.fields.label} {props.validation.required ? <span style={{ color: "red" }}>&nbsp;*&nbsp;</span> : <span></span>}</span>}
                {!props.CustomStyles && <span>{props.fields.label} {props.validation.required ? <span style={{ color: "red" }}>&nbsp;*&nbsp;</span> : <span></span>}</span>}
            </Typography> */}
            <StyledTextField {...props}
                id={props.customIdInput}
                style={props.fields?.styleInput}
                // value={CurrentState.value}
                size='small'
                variant='outlined'
                defaultValue={props.fields.defaultValue}
                type={props.fields.inputType}
                name={props.fields.key}
                placeholder={props.fields.placeholder}
                InputProps={varientCheck}
                disabled={props.disabled}
                required={props.validation.required}
                onChange={handleChange} />
            <Typography className='TextBoxCls' 
            style={props.fields.styleError}
            >
                {error && props.CustomStyles ? !error?.isValid && !props.disabled && (props.validation.required ? props.validation.required : CurrentState?.value?.trim().length !== 0) && (
                    <div>
                        {statusErrorCheck === 2 && <div style={{ color: props.WarningStyle?.borderColor?.toString() }}>{error?.message}</div>}
                        {statusErrorCheck === 3 && <div style={{ color: props.ErrorStyle?.borderColor?.toString() }}>{error?.message}</div>}
                        {statusErrorCheck === 1 && <div style={{ color: props.NormalStyle?.borderColor?.toString() }}>{error?.message}</div>}
                    </div>
                ) : <div></div>}

                {error && !props.CustomStyles ? !error?.isValid && !props.disabled && (props.validation.required ? props.validation.required : CurrentState?.value?.trim().length !== 0) && (
                    <div className={`${errorWarning}`}>{error?.message}</div>
                ) : <div></div>}
            </Typography>

        </div>
    )
};



export default TextBox;
