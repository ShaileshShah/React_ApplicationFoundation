import i18next from "i18next";
import { initReactI18next } from "react-i18next";


i18next
    .use(initReactI18next)
    .init({
        lng: "en", //default language
        interpolation: {
            escapeValue: false,
            format: function (value, format, lng) {
                // console.log("Currency format print", format);
                const [option, ...additionalValues] = format!.split(',').map((v) => v.trim());
                if (option === 'uppercase') return value.toUpperCase();
                if (option === 'lowercase') return value.toLowerCase();
                if (option?.includes('currency')) {
                    return Intl.NumberFormat(lng, { style: 'currency', currency: additionalValues[0] }).format(value);
                }
                if (option === 'intlDate') return new Intl.DateTimeFormat().format(value); // -> "12/20/2012" if run in en-US locale with time zone America/Los_Angeles
                return value;
            }
        }
    });

export default i18next;