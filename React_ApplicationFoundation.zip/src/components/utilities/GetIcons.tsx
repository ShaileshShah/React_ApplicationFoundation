
import React from 'react'
import AddIcon from '@material-ui/icons/Add';
//AddTask Icon not available in material ui v4
import AddTaskIcon from '@material-ui/icons/Add';
import CheckIcon from '@material-ui/icons/Check';
import DeleteIcon from '@material-ui/icons/Delete';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
import RemoveIcon from '@material-ui/icons/Remove';
//ContentPaste Icon not available in material ui
import ContentPasteIcon from '@material-ui/icons/FileCopy';
import AutorenewIcon from '@material-ui/icons/Autorenew';
import PersonRoundedIcon from '@material-ui/icons/PersonRounded';
import ClearIcon from '@material-ui/icons/Clear';
import LaunchIcon from '@material-ui/icons/Launch';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import ArrowDropUpIcon from '@material-ui/icons/ArrowDropUp';
import WarningIcon from '@material-ui/icons/Warning';
import ErrorOutlineIcon from '@material-ui/icons/ErrorOutline';
import ErrorIcon from '@material-ui/icons/Error';
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward';
import ArrowUpwardIcon from '@material-ui/icons/ArrowUpward';
import CreateIcon from '@material-ui/icons/Create';
import KeyboardArrowDownSharpIcon from '@material-ui/icons/KeyboardArrowDownSharp';
import KeyboardArrowUpSharpIcon from '@material-ui/icons/KeyboardArrowUpSharp';
import ErrorSharpIcon from '@material-ui/icons/ErrorSharp';
import HelpOutlineRoundedIcon from '@material-ui/icons/HelpOutlineRounded';
import DoneIcon from '@material-ui/icons/Done';

export const GetIcons = (val?: string, style?:{}) => {
    switch (val) {
      case 'Addicon': return <AddIcon style={style} />
      case 'RemoveIcon': return <RemoveIcon style={style} />
      case 'AddTask': return <AddTaskIcon style={style} />
      case 'checkIcon': return <CheckIcon style={style} />
      case 'Delete': return <DeleteIcon style={style} />
      case 'Highlight': return <HighlightOffIcon style={style} />      
      case 'ContentPasteIcon': return <ContentPasteIcon style={style} />
      case 'AutorenewIcon': return <AutorenewIcon style={style} />
      case 'PersonRoundedIcon': return <PersonRoundedIcon style={style} />
      case 'ClearIcon': return <ClearIcon style={style}/>
      case 'LaunchIcon': return <LaunchIcon style={style}/>
      case 'ArrowDropDownIcon': return <ArrowDropDownIcon style={style} />
      case 'DoneIcon': return <DoneIcon style={style} />
      case 'ArrowDropUpIcon': return <ArrowDropUpIcon style={style}/>
      case 'HelpIcon': return <svg style={style}  viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="5" cy="5" r="5" fill="#FFCA2C"/>
      <path d="M5.39738 6.12576H4.45398C4.45645 5.89055 4.47372 5.688 4.50578 5.51812C4.54031 5.34563 4.59827 5.19013 4.67966 5.05161C4.76352 4.9131 4.8745 4.77589 5.01262 4.63999C5.12854 4.53022 5.22967 4.42568 5.31599 4.32637C5.40231 4.22705 5.47014 4.12513 5.51947 4.02059C5.56879 3.91343 5.59346 3.79452 5.59346 3.66385C5.59346 3.51226 5.57126 3.38681 5.52687 3.2875C5.48494 3.18557 5.42081 3.10848 5.33449 3.05621C5.25063 3.00394 5.14458 2.9778 5.01632 2.9778C4.91027 2.9778 4.81161 3.00263 4.72036 3.05229C4.6291 3.09933 4.55387 3.17251 4.49468 3.27182C4.43795 3.37113 4.40836 3.50181 4.40589 3.66385H3.33301C3.34041 3.3058 3.4181 3.01047 3.56608 2.77787C3.71653 2.54265 3.91754 2.36886 4.16912 2.25648C4.42069 2.14148 4.70309 2.08398 5.01632 2.08398C5.36162 2.08398 5.65759 2.14409 5.90422 2.26432C6.15086 2.38192 6.33954 2.55572 6.47026 2.78571C6.60098 3.01308 6.66634 3.29011 6.66634 3.6168C6.66634 3.84418 6.62441 4.04672 6.54055 4.22444C6.4567 4.39955 6.34694 4.56289 6.21129 4.71447C6.07564 4.86606 5.92642 5.02287 5.76364 5.1849C5.62306 5.31819 5.52687 5.45801 5.47507 5.60437C5.42574 5.75073 5.39985 5.92452 5.39738 6.12576ZM4.343 7.33712C4.343 7.16986 4.39726 7.03134 4.50578 6.92157C4.6143 6.80919 4.75982 6.753 4.94233 6.753C5.12238 6.753 5.26666 6.80919 5.37518 6.92157C5.48617 7.03134 5.54166 7.16986 5.54166 7.33712C5.54166 7.49916 5.48617 7.63637 5.37518 7.74875C5.26666 7.86113 5.12238 7.91732 4.94233 7.91732C4.75982 7.91732 4.6143 7.86113 4.50578 7.74875C4.39726 7.63637 4.343 7.49916 4.343 7.33712Z" fill="#181818"/>
      </svg>      
      case 'HelpOutlineRoundedIcon': return <HelpOutlineRoundedIcon style={style}/>
      case 'WarningIcon': return <WarningIcon style={style}/>
      case 'ErrorOutlineIcon': return <ErrorOutlineIcon style={style}/>
      case 'ErrorIcon': return <ErrorIcon style={style}/>
      case 'ArrowDownwardIcon': return <ArrowDownwardIcon style={style}/>
      case 'ArrowUpwardIcon': return <ArrowUpwardIcon style={style} />
      case 'CreateIcon': return <CreateIcon style={style}/>
      case 'ErrorSharpIcon': return <ErrorSharpIcon style={style}/>
      case 'KeyboardArrowDownSharpIcon': return <KeyboardArrowDownSharpIcon style={style} />
      case 'KeyboardArrowUpSharpIcon': return <KeyboardArrowUpSharpIcon  style={style} />  
      case 'DownloadIcon': return <svg viewBox="0 0 10 10" style={style} fill="none" xmlns="http://www.w3.org/2000/svg">
      <path style={style} d="M8.38509 4.48661C8.4936 4.375 8.4936 4.19643 8.38509 4.10714L7.95106 3.66071C7.86426 3.54911 7.69065 3.54911 7.58214 3.66071L5.54221 5.82589V0.267857C5.54221 0.133929 5.4337 0 5.28179 0H4.67415C4.54395 0 4.41374 0.133929 4.41374 0.267857V5.82589L2.39551 3.66071C2.287 3.54911 2.11339 3.54911 2.02658 3.66071L1.59256 4.10714C1.48405 4.19643 1.48405 4.375 1.59256 4.48661L4.80436 7.79018C4.91287 7.90179 5.06478 7.90179 5.17329 7.79018L8.38509 4.48661ZM8.90592 8.83929H1.09342C0.941515 8.83929 0.833008 8.97321 0.833008 9.10714V9.73214C0.833008 9.88839 0.941515 10 1.09342 10H8.90592C9.03613 10 9.16634 9.88839 9.16634 9.73214V9.10714C9.16634 8.97321 9.03613 8.83929 8.90592 8.83929Z" fill="#165393"/>
      </svg>
      default: return <AddIcon />
    }
  }