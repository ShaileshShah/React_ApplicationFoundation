 const handleValidation = (field:any, currentstate:any) => {
    let isValid = true;
    let validation = field;
    let message = '';
    let errors = { isValid, message };
  
    let DefaulNeumericRegex = "^[0-9]*$";

    if (!validation) {
      errors = { isValid, message };
      return errors;
    }
  
     if (validation.required) {
      isValid =
        field.required
          ? currentstate["value"]?.trim() !== '' && isValid
          : currentstate["value"].length > 0 && isValid;
      isValid ? (message = '') : (message = validation.requiredErrorMsg?.trim().length === 0 || validation.requiredErrorMsg === undefined || validation.requiredErrorMsg === null ? "it is required" : validation.requiredErrorMsg);
      errors = { isValid, message };
    }
  
   
  
    if (validation.maxLength) {
      isValid =
        currentstate["value"]?.length <= validation.maxLength && isValid;
      isValid
        ? (message = '')
        : currentstate["value"]?.trim() === ''
        ? (message = validation.requiredErrorMsg?.trim().length === 0 || validation.requiredErrorMsg === undefined || validation.requiredErrorMsg === null ? "it is required" : validation.requiredErrorMsg)
        : (message = validation.maxLengthErrorMsg?.trim().length === 0 || validation.maxLengthErrorMsg === undefined || validation.maxLengthErrorMsg === null ? `should be atmost ${validation.maxLength} characters long` : validation.maxLengthErrorMsg);
      errors = { isValid, message };
    }

     if (validation.minLength) {
        isValid =
          currentstate["value"]?.trim().length >= validation.minLength && isValid;
        isValid
          ? (message = '')
          : currentstate["value"]?.trim() === ''
          ? (message = validation.requiredErrorMsg?.trim().length === 0  || validation.requiredErrorMsg === undefined || validation.requiredErrorMsg === null ? "it is required" : validation.requiredErrorMsg)
          : (message =  validation.minLengthErrorMsg?.trim().length === 0 || validation.minLengthErrorMsg === undefined || validation.minLengthErrorMsg === null ? `should be atleast ${validation.minLength} characters long` : validation.minLengthErrorMsg );
        errors = { isValid, message };
      }
  
    if (validation.isNumeric) {
      const pattern = new RegExp(DefaulNeumericRegex);
      isValid = pattern.test(currentstate["value"]) && isValid;
      isValid
      ? (message = '')
      : currentstate["value"]?.trim() === ''
      ? (message = validation.requiredErrorMsg?.trim().length === 0 || validation.requiredErrorMsg === undefined || validation.requiredErrorMsg === null  ? "it is required" : validation.requiredErrorMsg)
      : currentstate["value"].length > validation.maxLength
      ? (message =  validation.maxLengthErrorMsg?.trim().length === 0 || validation.maxLengthErrorMsg === undefined || validation.maxLengthErrorMsg === null ? `should be atmost ${validation.maxLength} characters long` : validation.maxLengthErrorMsg)
      : currentstate["value"].length < validation.minLength
      ? (message = validation.minLengthErrorMsg?.trim().length === 0 || validation.minLengthErrorMsg === undefined || validation.minLengthErrorMsg === null ? `should be atleast ${validation.minLength} characters long` : validation.minLengthErrorMsg)
      : !pattern.test(currentstate["value"])
      ? (message = validation.isNumericErrorMsg?.trim().length === 0  || validation.isNumericErrorMsg === undefined || validation.isNumericErrorMsg === null  ? `Incorrect pattern`:validation.isNumericErrorMsg )
      : (message = `` + ` ${validation.regexerror}`);
      errors = { isValid, message };
    }

   else if (validation.specialCharacterCheck || validation.required || validation.isNumeric || validation.minLength || validation.maxLength) {  
      const pattern = new RegExp(validation.regex);
      isValid = pattern.test(currentstate["value"]) && isValid;
      isValid
        ? (message = '')
        : currentstate["value"]?.trim() === ''
        ? (message = validation.requiredErrorMsg?.trim().length === 0 || validation.requiredErrorMsg === undefined || validation.requiredErrorMsg === null  ? "it is required" : validation.requiredErrorMsg)
        : currentstate["value"].length > validation.maxLength
        ? (message =  validation.maxLengthErrorMsg?.trim().length === 0 || validation.maxLengthErrorMsg === undefined || validation.maxLengthErrorMsg === null ? `should be atmost ${validation.maxLength} characters long` : validation.maxLengthErrorMsg)
        : currentstate["value"].length < validation.minLength
        ? (message = validation.minLengthErrorMsg?.trim().length === 0 || validation.minLengthErrorMsg === undefined || validation.minLengthErrorMsg === null ? `should be atleast ${validation.minLength} characters long` : validation.minLengthErrorMsg)
        : !pattern.test(currentstate["value"])
        ? (message = validation.regexErrorMsg?.trim().length === 0  || validation.regexErrorMsg === undefined || validation.regexErrorMsg === null  ? `Incorrect pattern`:validation.regexErrorMsg )
        : (message = `` + ` ${validation.regexerror}`);
      errors = { isValid, message };
    }
    return errors;
  };
  export default handleValidation