export const HEADER = {
  font: 'Arial',
  header1_fontSize: '24px',
  header2_fontSize: '18px',
  header1_lineheight: '28px',
  header2_lineheight: '24px',
  bold: 'bold',
  regular: 'normal',
  imagePadding: '2% 0px 0px 0px',
  gridPadding: '0px 15px 0px 15px',
}
export const SUBHEADER = {
  font: 'Arial',
  subHeader1_fontSize: '15px',
  subHeader2_fontSize: '12px',
  subheader1_lineheight: '18px',
  subheader2_lineheight: '16px',
  bold: 'bold',
  regular: 'normal',
  italics: 'italic',
}



export const TABLE={
    font:'Arial',
    fontSize:'13px',
    bold:'bold',
    regular:'normal',
    fontStyle:'normal',
    fontWeight:"400",
    lineHeight:"12px",
    color:"#000",
    padding: "3px 6px",
    tableBodyPadding : "4px",
    BackgroundColor:"#F4F4F4",
    ErrorIconStyle :{color:"#AA2B2D", fontSize:"20px",display:"flex",float:"right"},
    ErrorIconStyleHidden :{color:"#AA2B2D", fontSize:"20px",display:"flex",float:"right",visibility:"hidden",width:"15px"},
    WariningIconStyle :{color:"#FFCA2C", fontSize:"10px",display:"flex",float:"left", width:"15px"},
    WariningIconStyleHidden :{color:"#FFCA2C", fontSize:"15px",display:"flex",float:"left",visibility:"hidden",width:"15px"},
    DoneIconStyle :{color:"#378013", fontSize:"17px",display:"flex",float:"left", width:"15px"},
    DoneIconStyleHidden :{color:"#378013", fontSize:"15px",display:"flex",float:"left",visibility:"hidden",width:"15px"}
};

export const TABLETYPES={
    LabTable:'LabTable',
    VitalTable:'VitalTable',
    PatientSnapShotTable:'PatientSnapShotTable',
    RiskScoreTable:'RiskScoreTable',
    InfoRequiredTable:'InfoRequiredTable',
};

export const TABLIST = {
  textTransform: 'none',
  indicator: { backgroundColor: 'transparent', color: 'red' },
  root: { backgroundColor: '#E5E4E2', color: '#9229AA3' },
  tabSelected: { backgroundColor: 'white', color: 'black', fontweight: 'bold' },
  borderTop: '1px solid #B6B6B4',
  borderRight: '1px solid #B6B6B4',
  borderLeft: '1px solid #B6B6B4',
}
export const TABS = {
  textTransform: 'none',
  borderRadius: '5px 5px 0px 0px',
  fontcolor: 'black',
  hover: { fontcolor: 'Black' },
}
export const TABPANEL = {
  textTransform: 'none',
}

export const THRESHOLDBAR = {
  fontWeight_Pointer: 700,
  fontWeight_blockText: 400,
  fontSize_Pointer: '12px',
  fontSize_blockText: '10px',
  fontcolor_Pointer: '#FFFFFF',
  fontcolor_IndeterminatePointer: '#181818',
  fontcolor_blockText: '#646464',
}

export const FOOTERSUBTITLE = {
  font: 'Arial',
  gridPadding: '0px 10px 10px 10px',
  subtitleTwoFontSize: '13px',
  subtitleTwoLineheight: '12px',
  bodyRegularFontSize: '12px',
  bodyRegularLineheight: '14px',
  bodyRegularColor: '#165393',
  bodyRegularColorTwo: '#181818',
  captionFontSize: '8px',
  captionLineheight: '10px',
  captionColor: '#646464',
  bold: 'bold',
  regular: 'normal',
  italics: 'italic',
}

export const RISKTIMELINE = {
  lowMin: 1,
  lowMax: 3,
  intMin: 4,
  intMax: 5,
  highMin: 6,
  highMax: 10,

  lowLabel: 'Low',
  intLabel: 'Indeterminate',
  highLabel: 'High',
  toolTipStroke: '1.5px',

  toolTtipWidth: 85,
  toolTipWidthLow: 50,

  /** darken shades for text-labesl, left-border, tooltip line & stroke */
  lowPointerColor: '#1C68B8',
  intPointerColor: '#CACACA',
  highPointerColor: '#8A1D14',

  /**tier colors for diff ranges */
  lowTierColor: '#A4C3E3',
  intTierColor: '#E3E3E3',
  highTierColor: '#DEA7A3',

  lowTierColorSel: '#165393',
  intTierColorSel: '#4B4B4B',
  highTierColorSel: '#AC2419',

  pointRadius: 5,
  rectRadius: 10,
  xAxisTickSize: '8px',
  topMargin: 50,
  rightMargin: 20,
  bottomMargin: 20,
  leftMargin: 65,
}

export const COLOR = {
  idle: {
    low: {
      circleLineStroke: '#77A4D4',
      rectColor: '#A4C3E3',
      textColor: '#979797',
    },
    int: {
      circleLineStroke: '#979797',
      rectColor: '#E3E3E3',
      textColor: '#979797',
    },
    high: {
      circleLineStroke: '#CD7C75',
      rectColor: '#DEA7A3',
      textColor: '#FFFFFF',
    },
  },

  active: {
    low: {
      circleLineStroke: '#165393',
      rectColor: '#77A4D4',
      textColor: '#181818',
    },
    int: {
      circleLineStroke: '#4B4B4B',
      rectColor: '#CACACA',
      textColor: '#181818',
    },
    high: {
      circleLineStroke: '#8A1D14',
      rectColor: '#AC2419',
      textColor: '#FFFFFF',
    },
  },
}

export const TEXTBLOCK = {
  fontFamily:'Arial',
  color:'#181818',
  
}
