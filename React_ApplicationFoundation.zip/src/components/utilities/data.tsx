export const mainDivStylesObj = {}
export const InnerDivStylesObj = {}

export const columnData = [
  {
    lines: [
      { label: 'Beckman Coulter Diagnostics' },
      { label: 'Brea, CA 92821, USA' },
      { label: 'Phone number: 844-456-789' },
      {
        label: `© 2022 Beckman Coulter, Inc. All rights reserved. Beckman
        Coulter, the stylized logo, and the Beckman Coulter product
        and service marks mentioned herein are trademarks or
        registered trademarks of Beckman Coulter, Inc. in the United
        States and other countries. All other trademarks are the
        property of their respective owners.`,
        style: { fontSize: '8px', color: '#646464', lineHeight: '10px' },
      },
    ],
    style: { maxWidth: '30%' },
  },
  {
    lines: [
      {
        label: 'SOFTWARE',
        style: { fontWeight: 'bold', fontSize: '12px', lineheight: '12px' },
      },
      { label: 'Version:1.20.1' },
      { label: 'UDI:' },
      { label: '(01)12345678901234' },
      { label: '(17)123456' },
      { label: '(10)123456' },
      { label: '(21)1234' },
    ],
  },
  {
    lines: [
      {
        label: 'SUPPORT',
        style: { fontWeight: 'bold', fontSize: '12px', lineHeight: '10px' },
      },
      {
        label: 'View Clinical Validation Data',
        style: {
          color: '#165393',
          fontSize: '12px',
          textDecoration: 'none',
          lineHeight: '10px',
          display: 'flex',
          alignItems: 'center',
        },
      },
      { label: 'View Instructions for Use', style: { color: '#165393' } },
      {
        label: `Download Instructions for Use`,
        hyperLink: true,
        link: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
        targetBlank: '',
        icon: 'DownloadIcon',
        startIcon: true,
        endIcon: false,
        iconStyle: {},
        className: 'Class1',
        idName: 'Class1',
        download: true,
        style: {
          color: '#165393',
          fontSize: '12px',
          textDecoration: 'none',
          lineHeight: '10px',
          display: 'flex',
          alignItems: 'center',
        },
      },
    ],
  },
]

export const textBlockData = {
  totalCol: 3,
  bgColor: '#e0e0e0',
  header:
    'MACE CDS is intended for use with Emergency Department (ED) patients 22 years and over. The application is not intended for the following patient populations:',
  columns: [
    {
      subHeading: 'SUB Header',
      lines: [
        {
          label:
            'Lorem ipsum dolorLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Facilisis gravida neque convallis a cras semper auctor neque vitae. Lorem mollis aliquam ut porttitor. Ac orci phasellus egestas tellus. Neque laoreet suspendisse interdum consectetur libero id. Egestas sed sed risus pretium quam vulputate. Aliquam ultrices sagittis orci a. Ut ornare lectus sit amet. Interdum velit laoreet id donec ultrices tincidunt. Dui sapien eget mi proin sed libero enim sed faucibus.',
        },
      ],
    },
    {
      subHeading: 'SUB Header',
      lines: [
        {
          label:
            'Lorem ipsum dolorLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Facilisis gravida neque convallis a cras semper auctor neque vitae. Lorem mollis aliquam ut porttitor. Ac orci phasellus egestas tellus. Neque laoreet suspendisse interdum consectetur libero id. Egestas sed sed risus pretium quam vulputate. Aliquam ultrices sagittis orci a. Ut ornare lectus sit amet. Interdum velit laoreet id donec ultrices tincidunt. Dui sapien eget mi proin sed libero enim sed faucibus.',
        },
      ],
    },
    {
      subHeading: 'SUB Header',
      numberedList: true,
      lines: [
        {
          label: 'Patients presenting with cardiac arrest',
          style: {
            fontWeight: 'bold',
          },
        },
        {
          label: 'Patients requiring cardiac defibrillation',
        },
        {
          label: 'Patients presenting with Return of Spontaneous Circulation',
        },
      ],
    },
  ],
}
