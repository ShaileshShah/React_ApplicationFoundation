#!/bin/sh

#echo "Starting Keyvault shell script"
#./kv-script.sh
#echo "Keyvault shell script ended"

echo "Starting NPM"
npm start
echo "Ended NPM"